<div class="container">
    <h2>Forgot your password?</h2>
    <?php $this->session->flashdata('message'); ?>
	
    <!-- Status message -->
    <!-- <?php  
        if(!empty($success_msg)){ 
            echo '<p class="status-msg success">'.$success_msg.'</p>'; 
        }elseif(!empty($error_msg)){ 
            echo '<p class="status-msg error">'.$error_msg.'</p>'; 
        } 
    ?>  -->
	
    <!-- Login form -->
    <div class="regisFrm">
        <form action="<?php echo base_url('resetlink') ?>" method="POST">
        
            <div class="form-group">
            <label> Username: </label>
                <input type="email" name="email" placeholder="EMAIL">
                <span style='color:red'><?php echo form_error('email'); ?>
            </span>
            </div> 
            <br> 
            <div class="send-button">
                <input type="submit" name="loginSubmit" value="Send Reset Link">
            </div>
            <br>
        </form>

        <p>Don't have an account? <a href="<?php echo base_url('index.php/user_controller/registration'); ?>">Register</a></p>
    </div>
</div>