<?php
require_once __DIR__ . '/../lib/DataSource.php';
$database = new DataSource();
$isEdit = isset($_GET['id']);
$record = [];

if ($isEdit) {
    // Fetch the record from the database
    $sql = "SELECT * FROM users WHERE id=?";
    $paramType = 'i';
    $paramValue = array($_GET["id"]);
    $result = $database->select($sql, $paramType, $paramValue);
    $record = $result ? $result[0] : [];
}
?>