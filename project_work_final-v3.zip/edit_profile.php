<!DOCTYPE html>
<html>

<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" type="text/css" href="css/navbar.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php require_once __DIR__ . '/navbar.php'; ?>
    <h2>Edit Profile</h2>
    <form id="editProfileForm" enctype="multipart/form-data">
        <div class="row">
            <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label>
            <input type="text" name="name" id="name" class="full-width" required>
        </div>
        <div class="row">
            <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label>
            <input type="email" name="email" id="email" class="full-width" required>
        </div>
        <div class="row">
            <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label>
            <input type="text" name="mobile" id="mobile" class="full-width" required>
        </div>
        <div class="row">
            <label class="text-left">Upload Profile Picture: <span id="profile_picture-info" class="validation-message"></span></label>
            <input type="file" name="profile_picture" id="profile_picture" class="full-width">
            <input type="hidden" name="existing_profile_picture" id="existing_profile_picture" value="">
            <img id="profile-picture-preview" src="#" alt="Profile Picture" style="width: 100px; height: 100px; display:none;">
        </div>
        <div class="row">
            <input type="submit" value="Update Profile">
        </div>
    </form>
    <div id="responseMessage"></div>

    <script>
        // Check authentication
        $.ajax({
            url: 'auth.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (!response.authenticated) {
                    window.location.href = 'index.html';
                }
            },
            error: function(xhr, status, error) {
                console.log('Authentication check failed:', error);
            }
        });

        $(document).ready(function() {
            // Fetch user data when the page loads
            $.ajax({
                url: 'editprofile_query.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === "success") {
                        const userData = response.data;
                        $("#name").val(userData.name);
                        $("#email").val(userData.email);
                        $("#mobile").val(userData.mobile);
                        $("#existing_profile_picture").val(userData.profile_picture);
                        if (userData.profile_picture) {
                            $("#profile-picture-preview").attr("src", userData.profile_picture).show();
                        }
                    } else {
                        $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    $("#responseMessage").html("An error occurred while fetching data: " + xhr.responseText);
                }
            });

            // Profile picture preview
            $("#profile_picture").change(function() {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        $("#profile-picture-preview").attr("src", e.target.result).show();
                    }
                    reader.readAsDataURL(file);
                }
            });

            // Handle form submission
            $("#editProfileForm").on("submit", function(e) {
                e.preventDefault();

                const formData = new FormData(this);
                $.ajax({
                    url: 'update_profile.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            alert(response.message);
                            window.location.href = "dashboard.php";
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $("#responseMessage").html("An error occurred: " + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>

</html>
