<!DOCTYPE html>
<html>

<head>
    <title>PHP CRUD with Search and Pagination</title>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../css/navbar.css" />
    <link rel="stylesheet" type="text/css" href="../css/table.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        #employeeTable {
            margin: 0 auto;
            text-align: center;
            width: 90%;
        }

        #paginationContainer {
            margin-top: 20px;
            text-align: center;
        }

        .perpage-link {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 5px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            color: #333;
            text-decoration: none;
            cursor: pointer;
        }

        .perpage-link.current-page {
            background-color: #337ab7;
            color: #fff;
            border-color: #337ab7;
        }

        .perpage-link:hover {
            background-color: #ddd;
        }

        .btnSearch,
        .btnReset {
            padding: 8px 12px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 4px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            color: #333;
            text-decoration: none;
        }

        .btnReset {
            margin-left: 10px;
        }

        .font-bold {
            font-weight: bold;
        }

        .float-right {
            float: right;
        }

        .phppot-container {
            margin: 0 auto;
            width: 50%;
        }
    </style>
</head>

<body>
    <?php include 'navbar.php'; ?>

    <div class="phppot-container">
        <h1>Employee Management System</h1>

        <div>
            <form name="frmSearch" method="post" action="" id="searchForm">
                <div>
                    <p>
                        <input type="text" placeholder="Name" name="search[name]" id="search_name" />
                        <input type="text" placeholder="Designation" name="search[designation]" />
                        <input type="submit" name="go" class="btnSearch" value="Search" id="searchBtn">
                        <input type="reset" class="btnReset" value="Reset" onclick="window.location='index.php'">
                        <a class="font-bold btnAddNew" href="add_edit.php">Add New</a> <!-- Moved inside the div -->
                    </p>
                </div>
                <div class="float-left">
                    <span class="font-bold">Total Employee: </span> <span class="total-employee">0</span>
                </div>
                <table class="stripped">
                    <!-- Table structure from previous code -->
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Designation</th>
                            <th>Date of Birth</th>
                            <th>Date of Joining</th>
                            <th>Blood Group</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="employeeTable">
                    </tbody>
                </table>
            </form>
            <div id="paginationContainer">

            </div>
        </div>
    </div>
    <script src="js/navbar.js"></script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'auth.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (!response.authenticated) {
                        window.location.href = '../index.html';
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Authentication check failed:', error);
                }
            });

            function loadTable(formData) {
                $.ajax({
                    url: 'load_table.php',
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        var result = JSON.parse(response);
                        $('#employeeTable').html(result.table);
                        $('#paginationContainer').html(result.perpage);
                    }
                });
            }

            function loadTotalEmployees() {
                $.ajax({
                    url: 'get_total_employees.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.total !== undefined) {
                            $('.total-employee').text(response.total);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log('Failed to fetch total employees:', error);
                    }
                });
            }

            $('#searchForm').submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize();
                loadTable(formData);
            });

            $(document).on('click', '.perpage-link', function(e) {
                e.preventDefault();
                var page = $(this).val();
                var formData = $('#searchForm').serialize() + '&page=' + page;
                loadTable(formData);
            });

            $(document).on('click', '.deleteBtn', function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                if (confirm("Are you sure you want to delete this user?")) {
                    $.ajax({
                        url: 'delete.php',
                        type: 'GET',
                        data: {
                            id: id
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.status === 'success') {
                                alert(response.message);
                                loadTable($('#searchForm').serialize());
                                loadTotalEmployees();
                            } else {
                                alert("Failed to delete user.");
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                            alert("An error occurred while processing your request.");
                        }
                    });
                }
            });

            loadTable('');
            loadTotalEmployees();
        });
    </script>
</body>

</html>