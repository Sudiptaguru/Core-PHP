-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 01:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `designation` varchar(20) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `doj` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `del_flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `mobile`, `designation`, `dob`, `doj`, `address`, `blood_group`, `del_flag`) VALUES
(1, 'fdf', 'sudiptaguru710@gmail.com', '8513821591', 'fgg', '2024-05-01', '2024-05-01', 'gbngbjhn', 'AB', 0),
(2, 'fdf', 'sudiptaguru7@gmail.com', '8513821598', 'C', '2024-05-01', '2024-05-01', 'FFG', 'AB', 1),
(3, 'ccc', 'sudiptaguru90@gmail.com', '8513821591', 'C', '2024-05-01', '2024-05-01', 'jb njnmcc', 'AB+', 0),
(4, 'cdsxfaaa', 'aqq11@actovision.in', '8513821590', 'C', '05/01/2024', '05/01/2024', 'xvdxvgf', 'B', 0),
(5, 'cdsxfc', 'aqq@actovision.in', '8513821598', 'C', '05/01/2024', '05/01/2024', 'efrdrfderf', 'AB+', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `is_approve` int(11) DEFAULT 0,
  `del_flag` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `address`, `signature`, `role`, `profile_picture`, `is_approve`, `del_flag`) VALUES
(1, 'abcd', 'abc@gmail.com', '8513821598', 'Female', '2024-05-01', 'uhui', 'fdgg', '3', 'users/uploads/Screenshot (8).png', 1, 0),
(2, 'rtgrf', 'def@gmail.com', '8513821590', NULL, NULL, NULL, 'hgbhh', NULL, NULL, 0, 0),
(3, 'fdf', 'sudiptaguru710@gmail.com', '8513821591', 'Male', '05/01/2024', 'fcvfbv', 'fvbvb', '1', 'users/uploads/profile/Screenshot (6).png', 0, 0),
(4, 'fdf', 'sudiptaguru720@gmail.com', NULL, 'Male', '05/01/2024', 'fvbfv', 'dvf', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (1).png', 0, 0),
(5, 'fdf', 'sudiptaguru721@gmail.com', NULL, 'Male', '05/01/2024', 'fvggv', 'dfdfv', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (2) - Copy.png', 0, 0),
(6, 'fdf', 'sudiptaguru722@gmail.com', NULL, 'Male', '05/01/2024', 'fgtf', 'fvfgb', 'users/uploads/toy/Screenshot (3).png', 'users/uploads/profile/Screenshot (4).png', 0, 0),
(7, 'fdf', 'sudiptaguru723@gmail.com', '8513821598', 'Other', '05/01/2024', 'hbgh', 'cvdcg', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (1).png', 0, 0),
(8, 'abc', 'sudiptaguru725@gmail.com', '8513821598', 'Other', '05/01/2024', 'ghghg1', 'ghgh1', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (2) - Copy.png', 0, 1),
(9, 'fdf', 'sudiptaguru@gmail.com', '8513821598', 'Male', '2024-05-01', 'hbjh', 'fdgg', 'uploads/role/Screenshot (3).png', 'uploads/profile/Screenshot (5).png', 0, 0),
(10, 'cdsxfca', 'aqqa@actovision.in', '8513821591', 'Male', '01/01/2024', 'frgrfa', 'dgfvdfa', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 0),
(11, 'cdsxfca', 'aqqa2@actovision.in', '8513821591', 'Other', '01/01/2024', 'fgfga', 'fgbfga', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 1),
(12, 'cdsxfc', 'aqq@actovision.in', '8513821598', 'Male', '05/01/2024', 'sdsfdef', 'defft', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 1),
(13, 'cdsxfc', 'abc02@gmail.com', '8513821598', 'Male', '04/01/2024', 'dcgvdf', 'fgfg', 'Admin', 'users/uploads/profile/Screenshot (1).png', 0, 0),
(14, 'cdsxfc', 'abc05@gmail.com', '8513821598', 'Male', '04/01/2024', 'dregfrtg', 'gvrfg', '1', 'uploads/Screenshot (1).png', 0, 0),
(15, 'cdsxfc', 'abc2@gmail.com', '8513821598', 'Male', '05/01/2024', 'edtgf', 'gfrg', '1', 'users/uploads/Screenshot (2).png', 0, 0),
(16, 'cdsxfc', 'abc5@gmail.com', '8513821598', 'Male', '03/01/2024', 'bcv cvb ', 'cvbcvb ', '1', 'users/uploads/Screenshot (1).png', 0, 0),
(17, 'cdsxfc', 'abc7@gmail.com', '8513821598', 'Male', '05/01/2024', 'efedrf', 'dswdrf', '2', 'uploads/Screenshot (1).png', 1, 0),
(18, 'cdsxfc', 'abc10@gmail.com', '8513821598', 'Male', '05/01/2024', 'xcxdvf', 'dsefe', '1', 'users/uploads/Screenshot (3).png', 0, 0),
(19, 'cdsxfc', 'abc11@gmail.com', '8513821598', 'Male', '05/01/2024', 'qaswqaesw', 'dffvd', '1', 'uploads/Screenshot (1).png', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
