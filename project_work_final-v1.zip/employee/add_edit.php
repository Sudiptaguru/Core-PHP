<!DOCTYPE html>
<html>

<head>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link href="../css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script src="auth.js"></script>
    <script>
        $(document).ready(function() {
            $(".datepicker").datepicker();
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                maxDate: "+1Y"
            });

            function previewImage(input, imgElement) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $(imgElement).attr('src', e.target.result).css('display', 'block');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            $('#profile_picture').change(function() {
                previewImage(this, '#profile-picture-preview');
            });

            $('#mobile').on('keyup', function() {
                validateMobile(this);
            }).on('keypress', function(evt) {
                return restrictInput(evt);
            });

            function validateMobile(input) {
                var mobile = input.value;
                var mobileInfo = document.getElementById('mobile-info');
                if (mobile.length > 10 || isNaN(mobile)) {
                    mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                    input.value = input.value.slice(0, 10);
                } else {
                    mobileInfo.textContent = "";
                }
            }

            function restrictInput(evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            }

            var employeeId = new URLSearchParams(window.location.search).get('id');
            if (employeeId) {
                $.ajax({
                    url: 'edit_param.php',
                    type: 'GET',
                    data: {
                        id: employeeId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            var data = response.data;
                            $('#name').val(data.name);
                            $('#email').val(data.email);
                            $('#mobile').val(data.mobile);
                            $('#designation').val(data.designation);
                            $('#dob').val(data.dob);
                            $('#doj').val(data.doj);
                            $('#address').val(data.address);
                            $('#blood_group').val(data.blood_group);
                            $('#formTitle').text('Edit Record');
                            $('#btnSubmit').val('Save');
                            $('<input>').attr({
                                type: 'hidden',
                                name: 'id',
                                value: employeeId
                            }).appendTo('#frmToy');
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $("#responseMessage").html("An error occurred while fetching data: " + xhr.responseText);
                    }
                });
            }

            $("#frmToy").on("submit", function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                var url = employeeId ? 'update_employee.php' : 'process_form.php';

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var res = JSON.parse(response);
                        if (res.status === "success") {
                            alert(res.message);
                            window.location.href = "index.php";
                        } else {
                            alert(res.message);
                        }
                    }
                });
            });
        });
    </script>

    <style>
        .phppot-container {
            margin: 0 auto;
            width: 50%;
            /* Adjust as needed */
        }
    </style>
</head>

<body>
    <?php require_once __DIR__ . '/navbar.php'; ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" enctype="multipart/form-data" onClick="return validate();">
            <h1 id="formTitle">Add Record</h1>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label><input type="text" name="name" id="name" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label><input type="email" name="email" id="email" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label><input type="text" name="mobile" id="mobile" class="full-width " onkeyup="validateMobile(this);" onkeypress="return restrictInput(event);">
            </div>
            <div class="row">
                <label class="text-left">Designation: <span id="designation-info" class="validation-message"></span></label>
                <input type="text" name="designation" id="designation" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Date of Joining: <span id="doj-info" class="validation-message"></span></label>
                <input type="text" name="doj" id="doj" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label><textarea name="address" id="address" class="full-width"></textarea>
            </div>
            <div class="row">
                <label class="text-left">Blood Group: <span id="blood_group-count-info" class="validation-message"></span></label><input type="text" name="blood_group" id="blood_group" class="full-width ">
            </div>
            <div class="row">
                <input type="submit" name="submit" id="btnSubmit" class="full-width" value="Add" />
            </div>
        </form>
        <div id="responseMessage"></div>
    </div>
</body>

</html>