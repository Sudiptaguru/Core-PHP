<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Function to replace placeholders in the email template
function replacePlaceholders($template, $name, $comment) {
    $placeholders = array('{name}', '{comment}');
    $values = array($name, $comment);
    return str_replace($placeholders, $values, $template);
}

// Initialize PHPMailer
$mail = new PHPMailer(true);

try {
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';  // Your SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'sudiptaguru74@gmail.com';              // SMTP username
    $mail->Password   = 'foffnjiyjmjkpocp';              // SMTP password
    $mail->SMTPSecure = 'tls';                        // Enable TLS encryption
    $mail->Port       = 587;                          // TCP port to connect to

    // Email template
    $template = file_get_contents('email_template.html');

    // List of recipients and their comments
    $recipients = array(
        array('sudiptaguru3@gmail.com', 'John Doe', 'This is John\'s comment.'),
        array('sudiptaguru48@gmail.com', 'Jane Smith', 'Jane\'s feedback.'),
        // Add more recipients as needed
    );

    // Loop through recipients and send emails
    foreach ($recipients as $recipient) {
        $email = $recipient[0];
        $name = $recipient[1];
        $comment = $recipient[2];

        // Set up the email content
        $mail->setFrom('sudiptaguru74@gmail.com', 'Your Name');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Subject of the Email';
        $mail->Body = replacePlaceholders($template, $name, $comment);

        // Send the email
        $mail->send();

        // Clear recipients and attachments for the next iteration
        $mail->clearAddresses();
        $mail->clearAttachments();
    }

    echo 'Emails have been sent successfully';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
