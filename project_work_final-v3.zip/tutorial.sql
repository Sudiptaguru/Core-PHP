-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 03:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `designation` varchar(20) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `doj` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `del_flag` int(11) NOT NULL,
  `deleted_by` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `mobile`, `designation`, `dob`, `doj`, `address`, `blood_group`, `del_flag`, `deleted_by`, `created_at`, `updated_at`, `deleted_time`) VALUES
(1, 'fdf', 'sudiptaguru710@gmail.com', '8513821591', 'fgg', '2024-05-01', '2024-05-01', 'gbngbjhn', 'AB', 0, 0, NULL, NULL, NULL),
(2, 'fdf', 'sudiptaguru7@gmail.com', '8513821598', 'C', '2024-05-01', '2024-05-01', 'FFG', 'AB', 0, 0, NULL, NULL, NULL),
(3, 'ccc', 'sudiptaguru90@gmail.com', '8513821591', 'C', '2024-05-01', '2024-05-01', 'jb njnmcc', 'AB+', 0, 0, NULL, NULL, NULL),
(4, 'cdsxfaaa', 'aqq11@actovision.in', '8513821590', 'C', '05/01/2024', '05/01/2024', 'xvdxvgf', 'B', 0, 0, NULL, NULL, NULL),
(5, 'cdsxfc', 'aqq@actovision.in', '8513821598', 'C', '05/01/2024', '05/01/2024', 'efrdrfderf', 'AB+', 0, 0, NULL, NULL, NULL),
(6, 'cdsxfc', 'abc5@gmail.com', '8513821598', 'C', '05/01/2024', '05/01/2024', 'dsfdef', '', 0, 0, NULL, NULL, NULL),
(7, 'cdsxfc', 'abc@gmail.com', '8513821598', 'C', '05/01/2024', '05/01/2024', 'SDFSFR', 'B', 0, 0, NULL, NULL, NULL),
(8, 'cdsxfc', 'abc1@gmail.com', '8513821598', 'C', '05/01/2024', '05/01/2024', 'sdfcsf', 'O', 0, 0, NULL, NULL, NULL),
(9, 'cdsxfc', 'abc2@gmail.com', '8513821598', 'C', '05/01/2024', '05/01/2024', 'dfsef', 'AB', 0, 0, NULL, NULL, NULL),
(10, 'cdsxfc', 'abc3@gmail.com', '8513821598', 'C', '05/01/2024', '05/01/2024', 'wdfrf', 'AB', 0, 0, NULL, NULL, NULL),
(11, 'cdsxfc', 'abc4@gmail.com', '8513821590', 'C#', '05/01/2024', '05/01/2024', 'fertgf', 'O', 1, 2, NULL, NULL, '2024-05-29 17:59:48'),
(12, 'aaa', 'aaa@gmail.com', '8513821598', 'C++', '04/01/2024', '04/01/2024', 'DFEF', 'AB+', 0, 0, '2024-05-29 18:19:22', '2024-05-29 18:23:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `is_approve` int(11) DEFAULT 0,
  `del_flag` int(11) DEFAULT 0,
  `deleted_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `address`, `signature`, `role`, `profile_picture`, `is_approve`, `del_flag`, `deleted_by`, `created_at`, `updated_at`, `deleted_time`) VALUES
(1, 'abcd', 'abc@gmail.com', '8513821598', 'Female', '2024-05-01', 'uhui', 'fdgg', '3', 'users/uploads/Screenshot (8).png', 1, 0, 0, NULL, NULL, NULL),
(2, 'rtgrf', 'def@gmail.com', '8513821590', NULL, NULL, NULL, 'hgbhh', '2', NULL, 1, 0, 0, NULL, NULL, NULL),
(3, 'fdf', 'sudiptaguru710@gmail.com', '8513821591', 'Male', '05/01/2024', 'fcvfbv', 'fvbvb', '1', 'users/uploads/profile/Screenshot (6).png', 0, 0, 0, NULL, NULL, NULL),
(4, 'fdf', 'sudiptaguru720@gmail.com', NULL, 'Male', '05/01/2024', 'fvbfv', 'dvf', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (1).png', 0, 0, 0, NULL, NULL, NULL),
(5, 'fdf', 'sudiptaguru721@gmail.com', NULL, 'Male', '05/01/2024', 'fvggv', 'dfdfv', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (2) - Copy.png', 0, 0, 0, NULL, NULL, NULL),
(6, 'fdf', 'sudiptaguru722@gmail.com', NULL, 'Male', '05/01/2024', 'fgtf', 'fvfgb', 'users/uploads/toy/Screenshot (3).png', 'users/uploads/profile/Screenshot (4).png', 0, 0, 0, NULL, NULL, NULL),
(7, 'fdf', 'sudiptaguru723@gmail.com', '8513821598', 'Other', '05/01/2024', 'hbgh', 'cvdcg', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (1).png', 0, 0, 0, NULL, NULL, NULL),
(8, 'abc', 'sudiptaguru725@gmail.com', '8513821598', 'Other', '05/01/2024', 'ghghg1', 'ghgh1', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (2) - Copy.png', 0, 1, 0, NULL, NULL, NULL),
(9, 'fdf', 'sudiptaguru@gmail.com', '8513821598', 'Male', '2024-05-01', 'hbjh', 'fdgg', 'uploads/role/Screenshot (3).png', 'uploads/profile/Screenshot (5).png', 0, 0, 0, NULL, NULL, NULL),
(10, 'cdsxfca', 'aqqa@actovision.in', '8513821591', 'Male', '01/01/2024', 'frgrfa', 'dgfvdfa', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 0, 0, NULL, NULL, NULL),
(11, 'cdsxfca', 'aqqa2@actovision.in', '8513821591', 'Other', '01/01/2024', 'fgfga', 'fgbfga', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 1, 0, NULL, NULL, NULL),
(12, 'cdsxfc', 'aqq@actovision.in', '8513821598', 'Male', '05/01/2024', 'sdsfdef', 'defft', 'uploads/role/Screenshot (1).png', 'uploads/profile/Screenshot (3).png', 0, 1, 0, NULL, NULL, NULL),
(13, 'cdsxfc', 'abc02@gmail.com', '8513821598', 'Male', '04/01/2024', 'dcgvdf', 'fgfg', 'Admin', 'users/uploads/profile/Screenshot (1).png', 0, 0, 0, NULL, NULL, NULL),
(14, 'cdsxfc', 'abc05@gmail.com', '8513821598', 'Male', '04/01/2024', 'dregfrtg', 'gvrfg', '1', 'uploads/Screenshot (1).png', 0, 0, 0, NULL, NULL, NULL),
(15, 'cdsxfc', 'abc2@gmail.com', '8513821598', 'Male', '05/01/2024', 'edtgf', 'gfrg', '1', 'users/uploads/Screenshot (2).png', 0, 0, 0, NULL, NULL, NULL),
(16, 'cdsxfc', 'abc5@gmail.com', '8513821598', 'Male', '03/01/2024', 'bcv cvb ', 'cvbcvb ', '1', 'users/uploads/Screenshot (1).png', 0, 0, 0, NULL, NULL, NULL),
(17, 'cdsxfc', 'abc7@gmail.com', '8513821598', 'Male', '05/01/2024', 'efedrf', 'dswdrf', '2', 'uploads/Screenshot (1).png', 1, 0, 0, NULL, NULL, NULL),
(18, 'sss', 'abc10@gmail.com', '8513821598', 'Male', '05/01/2024', 'xcxdvf', 'dsefe', '1', 'users/uploads/Screenshot (3).png', 0, 0, 0, NULL, '2024-05-29 18:36:08', NULL),
(19, 'cdsxfcAx', 'abc12@gmail.com', '8513821591', 'Male', '05/01/2024', 'qaswqaesa', 'dffva', '2', 'uploads/Screenshot (1).png', 1, 1, 2, NULL, NULL, NULL),
(20, 'yyy', 'abc13@gmail.com', '8513821598', 'Female', '05/01/2024', 'retg', 'grfgt', '1', 'uploads/Screenshot (1).png', 0, 0, 0, NULL, '2024-05-29 18:35:52', NULL),
(21, 'ccc', 'ccc@gmail.com', '8513821598', 'Male', '04/01/2024', 'defdf', 'fdrefv', '1', 'uploads/Screenshot (1).png', 0, 0, 0, '2024-05-29 18:28:00', '2024-05-29 18:33:38', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
