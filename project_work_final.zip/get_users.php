<?php
include 'db_connection.php';

// Number of records per page
$limit = 10;
// Default page number
$page = isset($_GET['page']) ? $_GET['page'] : 1;
// Calculate starting record for pagination
$start = ($page - 1) * $limit;
// Search term (if any)
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Construct the SQL query
$sql = "SELECT * FROM users";
if (!empty($search)) {
    $sql .= " WHERE name LIKE '%$search%' OR role LIKE '%$search%'";
}
$sql .= " LIMIT $start, $limit";

// Execute the query
$result = $conn->query($sql);

// Array to hold fetched user records
$users = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Calculate total number of pages for pagination
$total_sql = "SELECT COUNT(id) AS total FROM users";
if (!empty($search)) {
    $total_sql .= " WHERE name LIKE '%$search%' OR role LIKE '%$search%'";
}
$total_result = $conn->query($total_sql);
$row = $total_result->fetch_assoc();
$total_pages = ceil($row["total"] / $limit);

// Prepare response array
$response = array(
    'users' => $users,
    'totalPages' => $total_pages
);

// Set response header to JSON
header('Content-Type: application/json');
// Output JSON response
echo json_encode($response);
?>
