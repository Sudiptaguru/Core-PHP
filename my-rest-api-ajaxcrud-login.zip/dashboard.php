<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h2>Dashboard</h2>
    <div id="userInfo"></div>
    <button id="logoutButton">Logout</button>

    <script>
        $(document).ready(function() {
            // Check if user is logged in
            $.ajax({
                url: "http://localhost/my-rest-api-ajaxcrud/api/index.php?action=login",
                type: "GET",
                success: function(response) {
                    $("#userInfo").html("<p>Welcome, " + response.user.name + "!</p>");
                },
                error: function(xhr) {
                    // Redirect to login page if not logged in
                    window.location.href = "login.html";
                }
            });

            // Logout button click event
            $("#logoutButton").click(function() {
                $.ajax({
                    url: "http://localhost/my-rest-api-ajaxcrud/api/index.php?action=logout",
                    type: "POST",
                    success: function(response) {
                        window.location.href = "login.html";
                    }
                });
            });
        });
    </script>
</body>
</html>
