# College Management Project
### CMP is the project based on college students records and the course they are having. 
Clone it and try to find out the intersting features inside.

Languages used in Project: PHP
Framework: Codeigniter
Front-end: HTML/CSS, Bootstrap

# Read More About Codeigniter in Readme.rst file or visit https://codeigniter.com/
