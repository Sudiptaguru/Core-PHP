<?php
require_once __DIR__ . '/../lib/DataSource.php';

if(isset($_GET["id"]) && !empty($_GET["id"])) {
    $database = new DataSource();
    $sql = "UPDATE users SET del_flag = 1 WHERE id=?";
    $paramType = 'i';
    $paramValue = array(
        $_GET["id"]
    );
    $database->update($sql, $paramType, $paramValue);
    echo json_encode(array("status" => "success", "message" => "User soft-deleted successfully."));
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
