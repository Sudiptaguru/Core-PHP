<?php
// next_page.php

session_start();

if (isset($_SESSION['encoded_value'])) {
    // Decode the value
    $decodedValue = base64_decode($_SESSION['encoded_value']);
    $dataQty = base64_decode($_SESSION['data_qty']);
    $dataImg = base64_decode($_SESSION['data_img']);

    // Display details or perform other actions with $decodedValue
    echo "<h2>Details for: $decodedValue</h2>";
    echo "<p>Data Qty: $dataQty</p>";
     echo "<p>Data Qty: $dataImg</p>";

    // Clear the session variable
    unset($_SESSION['encoded_value']);
    unset($_SESSION['data_qty']);
    unset($_SESSION['data_img']);
} else {
    // Handle the case when the encoded value is not present
    echo "Error: Encoded value not found.";
}
?>
