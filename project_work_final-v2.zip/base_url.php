<?php
function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $path = dirname($script);
    
    return rtrim($protocol . $host . $path, '/');
}

$response = array('base_url' => getBaseUrl());

header('Content-Type: application/json');
echo json_encode($response);
exit;
?>
