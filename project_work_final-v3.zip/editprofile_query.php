<?php
require_once __DIR__ . '/lib/DataSource.php';
session_start();

// Check if user is not logged in
if (!isset($_SESSION['email'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

// Database connection
$database = new DataSource();

// Retrieve email from session
$email = $_SESSION['email'];

// Fetch user data from the database
$query = "SELECT * FROM users WHERE email = ?";
$params = [$email];
$result = $database->select($query, 's', $params);

if ($result) {
    echo json_encode(['status' => 'success', 'data' => $result[0]]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found or not approved.']);
}
?>
