<?php
class passwordreset extends CI_Controller{
	function pwdreset{
	$mobile = ($this->input->post('mobile'));
$fourRandomDigit = rand(1000,9999);

$fourRandomDigit;  
$_session['otp'] = $fourRandomDigit;
$sms = api_url?mob=1234567890&txt=$fourRandomDigit

submit
$otp = $_POST['otp']
if($otp == $_session['otp'])
{
	su
}
else
{
	//invalid otp
}
$userData = array( 
                'mobile' => $this->input->post('mobile')
            ); 
$this->load->view('reset');
}
}
?>