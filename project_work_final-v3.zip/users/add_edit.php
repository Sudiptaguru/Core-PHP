<!DOCTYPE html>
<html>

<head>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link href="../css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../css/navbar.css" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script src="js/navbar.js"></script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'auth.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (!response.authenticated) {
                        window.location.href = '../index.html';
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Authentication check failed:', error);
                }
            });
            $(".datepicker").datepicker();
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                maxDate: "+1Y"
            });

            function previewImage(input, imgElement) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $(imgElement).attr('src', e.target.result).css('display', 'block');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            $('#profile_picture').change(function() {
                previewImage(this, '#profile-picture-preview');
            });

            $('#mobile').on('keyup', function() {
                validateMobile(this);
            }).on('keypress', function(evt) {
                return restrictInput(evt);
            });

            function validateMobile(input) {
                var mobile = input.value;
                var mobileInfo = document.getElementById('mobile-info');
                if (mobile.length > 10 || isNaN(mobile)) {
                    mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                    input.value = input.value.slice(0, 10);
                } else {
                    mobileInfo.textContent = "";
                }
            }

            function restrictInput(evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            }

            var userId = new URLSearchParams(window.location.search).get('id');
            if (userId) {
                $.ajax({
                    url: 'edit_param.php',
                    type: 'GET',
                    data: {
                        id: userId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            var data = response.data;
                            $('#id').val(data.id);
                            $('#name').val(data.name);
                            $('#email').val(data.email);
                            $('#mobile').val(data.mobile);
                            $('#gender').val(data.gender);
                            $('#address').val(data.address);
                            $('#signature').val(data.signature);
                            $('#dob').val(data.dob);
                            $('#role').val(data.role);
                            $('#profile-picture-preview').attr('src', data.profile_picture).css('display', 'block');
                            $('#existing_profile_picture').val(data.profile_picture);
                            $('.form_heading').html('Edit Record');
                            $('#is_approve').val(data.is_approve);
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $("#responseMessage").html("An error occurred while fetching data: " + xhr.responseText);
                    }
                });
            } else {
                $('.is_approve').hide();
            }

            $('#frmToy').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                var actionUrl = userId ? 'update_user.php' : 'process_form.php';

                $.ajax({
                    url: actionUrl,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var jsonResponse = JSON.parse(response);
                        if (jsonResponse.status === 'success') {
                            alert(jsonResponse.message);
                            window.location.href = "index.php";
                        } else {
                            alert(jsonResponse.message);
                        }
                    }
                });
            });
        });
    </script>

    <style>
        .phppot-container {
            margin: 0 auto;
            width: 50%;
        }
    </style>
</head>

<body>
    <?php require_once __DIR__ . '/navbar.php'; ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" enctype="multipart/form-data" onClick="return validate();">
            <h1 class="form_heading">Add Record</h1>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label>
                <input type="text" name="name" id="name" class="full-width">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label>
                <input type="email" name="email" id="email" class="full-width">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label>
                <input type="text" name="mobile" id="mobile" class="full-width">
            </div>
            <div class="row">
                <label class="text-left">Gender: <span id="gender-info" class="validation-message"></span></label>
                <select name="gender" id="gender" class="full-width">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label>
                <textarea name="address" id="address" class="full-width"></textarea>
            </div>
            <div class="row">
                <label class="text-left">Signature: <span id="signature-info" class="validation-message"></span></label>
                <textarea name="signature" id="signature" class="full-width"></textarea>
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker">
            </div>
            <div class="row is_approve">
                <label class="text-left">Is Approve: <span id="is_approve-info" class="validation-message"></span></label>
                <select name="is_approve" id="is_approve" class="full-width">
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="row">
                <label class="text-left">Role: <span id="role-info" class="validation-message"></span></label>
                <select name="role" id="role" class="full-width">
                    <option value="1">Admin</option>
                    <option value="2">Super Admin</option>
                    <option value="3">User</option>
                </select>
            </div>
            <div class="row">
                <label class="text-left">Upload Profile Picture: <span id="profile_picture-info" class="validation-message"></span></label>
                <input type="file" name="profile_picture" id="profile_picture" class="full-width">
                <input type="hidden" name="existing_profile_picture" id="existing_profile_picture" value="">
                <img id="profile-picture-preview" src="#" alt="Profile Picture" style="width: 100px; height: 100px; display:none;">
            </div>
            <div class="row">
                <input type="hidden" name="id" id="id" value="">
                <input type="submit" name="submit" id="btnAddAction" class="full-width" value="<?php echo isset($_GET['id']) ? 'Save' : 'Submit'; ?>" />
            </div>
        </form>
    </div>
</body>

</html>