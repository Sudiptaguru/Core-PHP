<?php
require_once __DIR__ . '/../lib/DataSource.php';
session_start();
header('Content-Type: application/json');

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    echo json_encode(["status" => "error", "message" => "You must be logged in to update your profile."]);
    exit;
}

$database = new DataSource();
$email = $_SESSION['email'];

// Get the user ID based on the email from the session
$query = "SELECT id FROM users WHERE email = ?";
$params = [$email];
$result = $database->select($query, 's', $params);

// Check if the user ID was found
// if (empty($result)) {
//     echo json_encode(["status" => "error", "message" => "User not found."]);
//     exit;
// }

$userId = $result[0]['id'];

// Check if the 'id' parameter is set and not empty
if (isset($_GET["id"]) && !empty($_GET["id"])) {
    $sql = "UPDATE users SET del_flag = 1, deleted_by = ? WHERE id = ?";
    $paramType = 'ii';
    $paramValue = [$userId, $_GET["id"]];
    $updateResult = $database->update($sql, $paramType, $paramValue);

    // Check if the update was successful
    if ($updateResult) {
        echo json_encode(["status" => "success", "message" => "User soft-deleted successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to soft-delete user."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
}
?>
