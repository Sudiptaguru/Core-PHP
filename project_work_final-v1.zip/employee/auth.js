$.ajax({
    url: 'check_auth.php',
    method: 'GET',
    dataType: 'json',
    success: function(response) {
        if (!response.authenticated) {
            window.location.href = '../index.html';
        }
    },
    error: function(xhr, status, error) {
        console.log('Authentication check failed:', error);
    }
});