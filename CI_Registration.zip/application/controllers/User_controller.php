<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class User_controller extends CI_Controller { 
     
    function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        $this->load->model('User');
    } 
    public function login()
    {
        $this->load->view('user_login');
    } 

    public function login_check()
    {
        $email=$this->input->post('email');
        $password=md5($this->input->post('password'));
        $data = array('email'=>$email,'password'=>$password);
        //$data = array('name'=>$name,'email'=>$email,'password'=>$password);
        $row = $this->User->login_check($data);
echo "<pre>";
        // print_r($row);
        if ($row == TRUE) {
           
           
            
           // modified by sanjit on 20200917
            $session_data = array(
            'id' => $row[0]->id,
            // 'first_name' => $row[0]->first_name,
            // 'email' => $row[0]->email
            );
            // print_r($session_data);die;
            $this->session->set_userdata('logged_in', $session_data);
           redirect('user_controller/userProfile');
        }
        else{
            // $this->session->set_flashdata('res_msg', '<h5 style="color:red; border: 1px solid red;">OOPS! Please Enter Correct Email or Password</h5>');
            redirect('user_controller/login');
        }
        
          
    } 

    public function userProfile()
    {
        
        $logged_in=$this->session->userdata('logged_in');
 $user_id=$logged_in['id'];
        $data['profile']=$this->User->get_user($user_id);
        //print_r($data['profile']);
        // $this->load->model('User');
        if(isset($logged_in['id'])){
            $this->load->view('user_profile',$data);
        }
        else{
            redirect('user_controller/login');
        }
        
    }
    
    public function registration(){ 
    $data = $userData = array(); 
         
        // If registration request is submitted 
        if($this->input->post('signupSubmit')){ 
            $this->form_validation->set_rules('first_name', 'First Name', 'required|alpha'); 
            $this->form_validation->set_rules('last_name', 'Last Name', 'required|alpha'); 
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email'); 
            $this->form_validation->set_rules('password', 'password', 'required|min_length[8]|max_length[15]'); 
            
            $this->form_validation->set_rules('conf_password', 'confirm password', 'required|matches[password]|min_length[8]|max_length[15]');

            $this->form_validation-> set_rules('gender', 'Gender', 'required' );

            $this->form_validation->
             set_rules('phone','contact no','required|exact_length[10]');
 
            $userData = array( 
                'first_name' => strip_tags($this->input->post('first_name')), 
                'last_name' => strip_tags($this->input->post('last_name')), 
                'email' => strip_tags($this->input->post('email')), 
                'password' => md5($this->input->post('password')), 
                'gender' => $this->input->post('gender'), 
                'phone' => strip_tags($this->input->post('phone')) 
            ); 
            // print_r($userData);
            // die;
 
            if($this->form_validation->run() == true){ 
                $insert = $this->User->insert($userData); 
                // if($insert){ 
                    $this->session->set_userdata('success_msg', 'Your account registration has been successful. Please login to your account.'); 
            redirect('user_controller/login');
                    // $data['success_msg']= 'Your account registration has been successful. Please login to your account.';

                // }
                // else{ 
                //     $data['error_msg'] = 'Some problems occured in registration, please try again.'; 
                // } 
            }
            // else{ 
            //     $data['error_msg'] = 'Please fill all the fields.'; 
            // } 
        } 
         
        // Posted data 
        $data['user'] = $userData; 
         
        // Load view 
         
        $this->load->view('user_registration', $data); 
         
    }
    // function editUser($userId){
       
    //     $this->load->model('User');
    //     $data['user'] = $this->User->getSingleUser($userId);
    //     $this->load->view('updateForm',$data);
    // }
    
    public function logout(){ 
        // $this->session->unset_userdata('lolgin_check'); 
        // $this->session->unset_userdata(''); 
        $this->session->sess_destroy(); 
        //$this->load->view('user_login');
        redirect('user_controller/login');
    }

    // Existing email check during validation 
    public function email_check($str){ 
        $con = array( 
            'returnType' => 'count', 
            'conditions' => array( 
                'email' => $str 
            ) 
        ); 
        $checkEmail = $this->User->getRows($con); 
        if($checkEmail > 0){ 
            $this->form_validation->set_message('email_check', 'The given email already exists.'); 
            return FALSE; 
        }else{ 
            return TRUE; 
        } 
    } 

    //  public function file_check($str){
    //     $allowed_mime_type_arr = array('image/gif','image/jpeg','image/jpg','image/png');
    //     $mime = get_mime_by_extension($_FILES['file']['name']);
    //     if(isset($_FILES['file']['name']) && $_FILES['file']['name']!=""){
    //         if(in_array($mime, $allowed_mime_type_arr)){
    //             return true;
    //         }else{
    //             $this->form_validation->set_message('file_check', 'Please select only pdf/gif/jpg/png file.');
    //             return false;
    //         }
    //     }else{
    //         $this->form_validation->set_message('file_check', 'Please choose a file to upload.');
    //         return false;
    //     }
    // }
    // function updateUser(){
    //     $setArray = [
    //             'first_name' => $this->input->post('name'),
    //             'phone' => $this->input->post('phone'),
                 
    //         ];
    //         $userId = $this->input->post('userId');
    //         $status = $this->User->update_User($setArray,$userId);
            
    //         if($status == true){
    //             $data['message'] = "<font color='green'>
    //             Successfully Updated </font>";
    //         }else{
    //             $data['message'] = "<font color='red'> Not upadted,Please Try Again </font>";
    //         }
    //         $data['userinfo'] = $this->User->getAllUserr();
    //         $this->load->view('User_controller/updateUser',$data);
        
    // }
    public function Forgotpassword()
    {
        $this->load->view('Forgotpassword');
    }
    // public function resetlink()
    // {
    //     $email=$this->input->post('email');
    //     $this->db->query("select * from users where email='".$email"'")->result_array();
    //     if(count($result)>0)
    //     {
    //         echo "Exist";
    //     }
    //     else
    //     {
    //         echo "Email not registered";
    //     }
    // }
}
?>