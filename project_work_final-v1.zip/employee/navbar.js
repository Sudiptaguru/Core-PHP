// $(document).ready(function() {
//     $.ajax({
//         url: 'fetch_user.php',
//         type: 'GET',
//         dataType: 'json',
//         success: function(data) {
//             if (!data || !data.userData) {
//                 console.error('Invalid data format received:', data);
//                 $('#userDropdown').text('Error loading data');
//                 return;
//             }
//             var userData = data.userData;
//             var isAdmin = data.isAdmin;

//             // Update the user's name in the dropdown button
//             $('#userDropdown').text(userData.name);

//             // Populate the dropdown content based on user role
//             var dropdownContent = '';
//             if (isAdmin) {
//                 dropdownContent += '<a href="admin_page.php">Admin Page</a>';
//             } else {
//                 dropdownContent += '<a href="../edit_profile.php?email=' + userData.email + '">Profile</a>';
//             }
//             dropdownContent += '<a href="../logout.php">Logout</a>';
//             $('#dropdownContent').html(dropdownContent);
//         },
//         error: function(xhr, status, error) {
//             console.error('AJAX Error: ' + status + ' ' + error);
//             $('#userDropdown').text('Error loading data');
//         }
//     });
// });

$.ajax({
    url: 'check_auth.php',
    type: 'GET',
    dataType: 'json',
    success: function (response) {
        if (response.authenticated) {
            // Fetch user data via AJAX
            $.ajax({
                url: 'fetch_user.php',
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    if (!data || !data.userData) {
                        console.error('Invalid data format received:', data);
                        $('.userDropdown').text('Error loading data');
                        return;
                    }
                    var userData = data.userData;
                    var isAdmin = data.isAdmin;

                    // Update the user's name in the dropdown button
                    $('.userDropdown').text(userData.name);

                    // Populate the dropdown content based on user role
                    var dropdownContent = '';
                    if (isAdmin) {
                        // dropdownContent += '<a href="#">Admin Page</a>';
                        dropdownContent += '';
                    } else {
                        dropdownContent += '<a href="edit_profile.php?email=' + userData.email + '">Profile</a>';
                    }
                    dropdownContent += '<a href="logout.php">Logout</a>';
                    $('#dropdownContent').html(dropdownContent);
                },
                error: function (xhr, status, error) {
                    console.error('AJAX Error: ' + status + ' ' + error);
                    $('.userDropdown').text('Error loading data');
                }
            });
        } else {
            // Redirect to login page if not authenticated
            window.location.href = 'index.html';
        }
    },
    error: function (xhr, status, error) {
        console.log(xhr.responseText);
        $("#welcomeMessage").text("An error occurred during authentication.");
        window.location.href = 'index.html';
    }
});