<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/navbar.css" />
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>

    <!-- Content -->
    <div style="padding:20px;">
        <p>This is a protected page.</p>
        <p id="" class="userDropdown">Loading...</p>
    </div>
</body>

</html>