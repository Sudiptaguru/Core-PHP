<?php
require_once __DIR__ . '/../lib/DataSource.php';

$database = new DataSource();
$response = array("status" => "error", "message" => "Unknown error occurred.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $id = $_POST["id"];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response["message"] = "Invalid email format";
    } else {
        // Fetch existing data
        $fetchQuery = "SELECT * FROM employee WHERE id = ?";
        $paramType = "i";
        $paramValue = array($id);
        $existingData = $database->select($fetchQuery, $paramType, $paramValue);

        if ($existingData) {
            $existingData = $existingData[0];
            // Check if there are changes
            $isChanged = false;
            $fields = ['name', 'designation', 'doj', 'address', 'mobile', 'blood_group', 'email'];
            foreach ($fields as $field) {
                if ($_POST[$field] != $existingData[$field]) {
                    $isChanged = true;
                    break;
                }
            }

            if ($isChanged) {
                $checkEmailQuery = "SELECT COUNT(*) as count FROM employee WHERE email = ? AND id != ?";
                $paramType = "si";
                $paramValue = array($email, $id);
                $result = $database->select($checkEmailQuery, $paramType, $paramValue);

                if ($result && $result[0]["count"] > 0) {
                    $response["message"] = "Email already exists.";
                } else {
                    $sql = "UPDATE employee SET name=?, designation=?, doj=?, address=?, mobile=?, blood_group=?, email=? WHERE id=?";
                    $paramType = 'sssssssi';
                    $paramValue = array(
                        $_POST["name"],
                        $_POST["designation"],
                        $_POST["doj"],
                        $_POST["address"],
                        $_POST["mobile"],
                        $_POST["blood_group"],
                        $email,
                        $id
                    );
                    $result = $database->execute($sql, $paramType, $paramValue);

                    if ($result) {
                        $response["status"] = "success";
                        $response["message"] = "Record updated successfully.";
                    } else {
                        $response["message"] = "Failed to update record.";
                    }
                }
            } else {
                // No changes, redirect
                $response["status"] = "no_change";
                $response["message"] = "No changes detected.";
            }
        } else {
            $response["message"] = "Employee not found.";
        }
    }
}

echo json_encode($response);
?>
