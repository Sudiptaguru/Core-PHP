<?php
require_once __DIR__ . '/../lib/DataSource.php';

$database = new DataSource();
$response = array('status' => 'error', 'message' => 'An error occurred');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    date_default_timezone_set("Asia/Kolkata");
    $created_at = date("Y-m-d H:i:s");
    $checkEmailQuery = "SELECT COUNT(*) as count FROM employee WHERE email = ?";
    $paramType = "s";
    $paramValue = array($email);
    $result = $database->select($checkEmailQuery, $paramType, $paramValue);

    // Check if the email already exists
    if ($result && $result[0]["count"] > 0) {
        $response['message'] = "Email already exists.";
    } else {
        $mobile = $_POST["mobile"];

        if (strlen($mobile) !== 10 || !is_numeric($mobile)) {
            $response['message'] = "Mobile number must be 10 digits and contain only numeric characters.";
        } else {
            $sql = "INSERT INTO employee(name, designation, dob, doj, address, blood_group, email, mobile, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $paramType = 'sssssssss';
            $paramValue = array(
                $_POST["name"],
                $_POST["designation"],
                $_POST["dob"],
                $_POST["doj"],
                $_POST["address"],
                $_POST["blood_group"],
                $email,
                $mobile,
                $created_at
            );
            $result = $database->insert($sql, $paramType, $paramValue);

            if (!$result) {
                $response['message'] = "Problem adding employee to the database. Please retry.";
            } else {
                $response['status'] = 'success';
                $response['message'] = 'Employee added successfully!';
            }
        }
    }
}

echo json_encode($response);
