<?php
require_once __DIR__ . '/../lib/DataSource.php';
$database = new DataSource();
$response = array('status' => 'error', 'message' => 'An error occurred');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Define directories for uploads
    $targetDirToy = "uploads/role/";
    $targetDirProfile = "uploads/profile/";

    // Target file paths
    $targetFileToy = $targetDirToy . basename($_FILES["role"]["name"]);
    $targetFileProfile = $targetDirProfile . basename($_FILES["profile_picture"]["name"]);

    // File types
    $imageFileTypeToy = strtolower(pathinfo($targetFileToy, PATHINFO_EXTENSION));
    $imageFileTypeProfile = strtolower(pathinfo($targetFileProfile, PATHINFO_EXTENSION));

    // Remove existing files if they exist
    if (file_exists($targetFileToy) && is_file($targetFileToy)) {
        unlink($targetFileToy);
    }
    if (file_exists($targetFileProfile) && is_file($targetFileProfile)) {
        unlink($targetFileProfile);
    }

    // Validate file size
    if ($_FILES["role"]["size"] > 500000) {
        $response['message'] = "User's file is too large.";
    } elseif ($_FILES["profile_picture"]["size"] > 500000) {
        $response['message'] = "Profile picture file is too large.";
    } elseif (!in_array($imageFileTypeToy, array("jpg", "jpeg", "png", "gif"))) {
        $response['message'] = "Only JPG, JPEG, PNG & GIF files are allowed for user files.";
    } elseif (!in_array($imageFileTypeProfile, array("jpg", "jpeg", "png", "gif"))) {
        $response['message'] = "Only JPG, JPEG, PNG & GIF files are allowed for profile pictures.";
    } elseif (move_uploaded_file($_FILES["role"]["tmp_name"], $targetFileToy) && move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFileProfile)) {
        // Insert data into the database if files are successfully uploaded
        $email = $_POST["email"];
        $checkEmailQuery = "SELECT COUNT(*) as count FROM users WHERE email = ?";
        $paramType = "s";
        $paramValue = array($email);
        $result = $database->select($checkEmailQuery, $paramType, $paramValue);

        // Check if the email already exists
        if ($result && $result[0]["count"] > 0) {
            $response['message'] = "Email already exists.";
        } else {
            // Validate mobile number
            $mobile = $_POST["mobile"];
            if (strlen($mobile) !== 10 || !is_numeric($mobile)) {
                $response['message'] = "Mobile number must be 10 digits and contain only numeric characters.";
            } else {
                // Insert the user data into the database
                $sql = "INSERT INTO users(name, gender, dob, address, signature, role, profile_picture, email, mobile) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $paramType = 'sssssssss';
                $paramValue = array(
                    $_POST["name"],
                    $_POST["gender"],
                    $_POST["dob"],
                    $_POST["address"],
                    $_POST["signature"],
                    $targetFileToy,
                    $targetFileProfile,
                    $email,
                    $mobile
                );
                $result = $database->insert($sql, $paramType, $paramValue);
                if (!$result) {
                    $response['message'] = "Problem adding user to the database. Please retry.";
                } else {
                    $response['status'] = 'success';
                    $response['message'] = 'User added successfully!';
                }
            }
        }
    } else {
        $response['message'] = "Sorry, there was an error uploading your file.";
    }
}
echo json_encode($response);
?>
