<?php
require_once __DIR__ . '/../lib/DataSource.php';

$database = new DataSource();
$response = array('status' => 'error', 'message' => 'An error occurred');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $checkEmailQuery = "SELECT COUNT(*) as count FROM employee WHERE email = ?";
    $paramType = "s";
    $paramValue = array($email);
    $result = $database->select($checkEmailQuery, $paramType, $paramValue);

    // Check if the email already exists
    if ($result && $result[0]["count"] > 0) {
        $response['message'] = "Email already exists.";
    } else {
        $mobile = $_POST["mobile"];

        if (strlen($mobile) !== 10 || !is_numeric($mobile)) {
            $response['message'] = "Mobile number must be 10 digits and contain only numeric characters.";
        } else {
            $sql = "INSERT INTO employee(name, designation, dob, doj, address, blood_group, email, mobile) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            $paramType = 'ssssssss';
            $paramValue = array(
                $_POST["name"],
                $_POST["designation"],
                $_POST["dob"],
                $_POST["doj"],
                $_POST["address"],
                $_POST["blood_group"],
                $email,
                $mobile
            );
            $result = $database->insert($sql, $paramType, $paramValue);

            if (!$result) {
                $response['message'] = "Problem adding user to the database. Please retry.";
            } else {
                $response['status'] = 'success';
                $response['message'] = 'User added successfully!';
            }
        }
    }
}

echo json_encode($response);
?>
