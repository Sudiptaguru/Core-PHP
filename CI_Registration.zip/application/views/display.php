<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Name of the workers:</h1>
<h3>
	<ol>
	<li>Name:<?php echo $n; ?><br>Age:<?php echo $a; ?></li>
</ol>
</h3>
</body>
</html>