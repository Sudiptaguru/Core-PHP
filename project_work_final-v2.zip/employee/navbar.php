

<!-- Navbar -->
<div class="navbar">
    <a href="#home">Home</a>

    <!-- User Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">User Management</button>
        <div class="dropdown-content">
            <a href="../users/User_add.php">Add User</a>
            <a href="../users/">View Users</a>
        </div>
    </div>

    <!-- Employee Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">Employee Management</button>
        <div class="dropdown-content">
            <a href="../employee/employee_add.php">Add Employee</a>
            <a href="../employee/">View Employees</a>
        </div>
    </div>

    <!-- User Info Dropdown -->
    <div class="dropdown right">
        <button id="userDropdown" class="dropbtn">Loading...</button>
        <div class="dropdown-content" id="dropdownContent">
            <!-- Content will be populated by jQuery -->
        </div>
    </div>
</div>
<script src="navbar.js"></script>

