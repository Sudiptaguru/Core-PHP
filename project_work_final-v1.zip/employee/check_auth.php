<?php
session_start();

$response = array('authenticated' => false);

if (isset($_SESSION['email'])) {
    $response['authenticated'] = true;
    $response['email'] = $_SESSION['email'];
} else {
    $response['message'] = 'User not authenticated';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
