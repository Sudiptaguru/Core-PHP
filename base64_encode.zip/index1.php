<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_form'])) {
    // Check if the form is submitted
    if (isset($_POST['selected_option'])) {
        // Encode the selected option and store it in a session variable
        $selectedOption = $_POST['selected_option'];
        $dataQty = $_POST['data_qty'];
        $dataImg = $_POST['data_img'];
        $_SESSION['encoded_value'] = base64_encode($selectedOption);
        $_SESSION['data_qty'] = base64_encode($dataQty);
        $_SESSION['data_img'] = base64_encode($dataImg);

        // Redirect to the next page
        header("Location: next_page1.php");
        exit();
    } else {
        // Debugging: Output an error message
        echo "Error: Selected option not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Option Example</title>
</head>

<body>
    <h2>Select an option:</h2>
    <form action="" method="post">
        <select name="selected_option" id="selected_option">
            <option value="Option 1" data-qty="1" data-img="a.jpg">Option 1</option>
            <option value="Option 2" data-qty="2" data-img="b.png">Option 2</option>
            <option value="Option 3" data-qty="3" data-img="c.png">Option 3</option>
        </select>
        <!-- Add hidden inputs for data-qty and data-img -->
        <input type="hidden" name="data_qty" id="data_qty" value="">
        <input type="hidden" name="data_img" id="data_img" value="">
        <input type="submit" name="submit_form" value="Submit">

        <!-- Script to update the hidden input value based on the selected option -->
        <script>
            document.getElementById('selected_option').addEventListener('change', function() {
                var selectedQty = this.options[this.selectedIndex].getAttribute('data-qty');
                var selectedImg = this.options[this.selectedIndex].getAttribute('data-img');
                document.getElementById('data_qty').value = selectedQty;
                document.getElementById('data_img').value = selectedImg;
            });

            // Trigger the change event on page load to ensure the initial value is captured
            document.getElementById('selected_option').dispatchEvent(new Event('change'));
        </script>
    </form>
</body>

</html>
