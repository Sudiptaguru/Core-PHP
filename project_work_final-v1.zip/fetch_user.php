<?php
require_once __DIR__ . '/lib/DataSource.php';
session_start();

// Check if user is not logged in
if (!isset($_SESSION['email'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit;
}

// Database connection
$database = new DataSource();

// Fetch users from the database where is_approve = 1
$queryCondition = "WHERE is_approve = 1";
$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM users " . $queryCondition . $orderby;
$result = $database->select($sql);

// Fetch admin data from JSON file
$adminData = json_decode(file_get_contents("admin.json"), true);

// Retrieve logged-in user's email from session
$email = $_SESSION['email'];

// Find the user's data from the fetched users and admin data
$userData = null;
$isAdmin = false;
foreach ($result as $user) {
    if ($user['email'] === $email) {
        $userData = $user;
        break;
    }
}
if (!$userData) {
    foreach ($adminData as $admin) {
        if ($admin['email'] === $email) {
            $userData = $admin;
            $isAdmin = true;
            break;
        }
    }
}

if ($userData) {
    $userData['isAdmin'] = $isAdmin;
    echo json_encode(['status' => 'success', 'data' => $userData]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'User not found.']);
}
?>
