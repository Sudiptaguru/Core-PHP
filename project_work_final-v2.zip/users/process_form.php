<?php
require_once __DIR__ . '/../lib/DataSource.php';
$database = new DataSource();
$response = array('status' => 'error', 'message' => 'An error occurred');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $targetDirProfile = "uploads/";

    // Create directory if it does not exist
    if (!is_dir($targetDirProfile)) {
        mkdir($targetDirProfile, 0777, true);
    }

    $targetFileProfile = $targetDirProfile . basename($_FILES["profile_picture"]["name"]);
    $imageFileTypeProfile = strtolower(pathinfo($targetFileProfile, PATHINFO_EXTENSION));

    // Validate file size
    if ($_FILES["profile_picture"]["size"] > 500000) {
        $response['message'] = "Profile picture file is too large.";
    } elseif (!in_array($imageFileTypeProfile, array("jpg", "jpeg", "png", "gif"))) {
        $response['message'] = "Only JPG, JPEG, PNG & GIF files are allowed for profile pictures.";
    } elseif (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFileProfile)) {
        $email = $_POST["email"];
        $checkEmailQuery = "SELECT COUNT(*) as count FROM users WHERE email = ?";
        $paramType = "s";
        $paramValue = array($email);
        $result = $database->select($checkEmailQuery, $paramType, $paramValue);

        if ($result && $result[0]["count"] > 0) {
            $response['message'] = "Email already exists.";
        } else {
            $mobile = $_POST["mobile"];
            if (strlen($mobile) !== 10 || !is_numeric($mobile)) {
                $response['message'] = "Mobile number must be 10 digits and contain only numeric characters.";
            } else {
                $sql = "INSERT INTO users(name, gender, dob, address, signature, role, profile_picture, email, mobile) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $paramType = 'sssssssss';
                $paramValue = array(
                    $_POST["name"],
                    $_POST["gender"],
                    $_POST["dob"],
                    $_POST["address"],
                    $_POST["signature"],
                    $_POST["role"],
                    $targetFileProfile,
                    $email,
                    $mobile
                );
                $result = $database->insert($sql, $paramType, $paramValue);
                if (!$result) {
                    $response['message'] = "Problem adding user to the database. Please retry.";
                } else {
                    $response['status'] = 'success';
                    $response['message'] = 'User added successfully!';
                }
            }
        }
    } else {
        $response['message'] = "Sorry, there was an error uploading your file.";
    }
}

echo json_encode($response);
?>
