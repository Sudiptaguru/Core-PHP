<?php
require_once __DIR__ . '/lib/perpage.php';
require_once __DIR__ . '/lib/DataSource.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../fetch_user.php';
$database = new DataSource();

$name = "";
$designation = "";

$queryCondition = "";
if (!empty($_POST["search"])) {
    foreach ($_POST["search"] as $k => $v) {
        if (!empty($v)) {

            $queryCases = array(
                "name",
                "designation"
            );
            if (in_array($k, $queryCases)) {
                if (!empty($queryCondition)) {
                    $queryCondition .= " AND ";
                } else {
                    $queryCondition .= " WHERE ";
                }
            }
            switch ($k) {
                case "name":
                    $name = $v;
                    $queryCondition .= "name LIKE '" . $v . "%'";
                    break;
                case "designation":
                    $designation = $v;
                    $queryCondition .= "designation LIKE '" . $v . "%'";
                    break;
            }
        }
    }
}
$orderby = " ORDER BY id desc";
$sql = "SELECT * FROM employee " . $queryCondition;
$href = 'index.php';

$perPage = 10;
$page = 1;
if (isset($_POST['page'])) {
    $page = $_POST['page'];
}
$start = ($page - 1) * $perPage;
if ($start < 0)
    $start = 0;

$query = $sql . $orderby . " limit " . $start . "," . $perPage;
$result = $database->select($query);

if (!empty($result)) {
    $result["perpage"] = showperpage($sql, $perPage, $href);
}
?>
<html>

<head>
    <title>PHP CRUD with Search and Pagination</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/table.css" />
    <link rel="stylesheet" type="text/css" href="css/form.css" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <style>
        button,
        input[type=submit].btnSearch {
            width: 140px;
            font-size: 14px;
            margin: 10px 0px 0px 10px;
        }

        .btnReset {
            width: 140px;
            padding: 8px 0px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 25px;
            color: #000000;
            border: 2px solid #d2d6dd;
            margin-top: 10px;
        }

        button,
        input[type=submit].perpage-link {
            width: auto;
            font-size: 14px;
            padding: 5px 10px;
            border: 2px solid #d2d6dd;
            border-radius: 4px;
            margin: 0px 5px;
            background-color: #fff;
            cursor: pointer;
        }

        .current-page {
            width: auto;
            font-size: 14px;
            padding: 5px 10px;
            border: 2px solid #d2d6dd;
            border-radius: 4px;
            margin: 0px 5px;
            background-color: #efefef;
            cursor: pointer;
        }

        .profile-picture {
            width: 50px;
            height: 50px;
        }
    </style>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>
    <div class="phppot-container">
        <h1>User Management System</h1>

        <div>
            <form name="frmSearch" method="post" action="">
                <div>
                    <p>
                        <input type="text" placeholder="Name" name="search[name]" value="<?php echo $name; ?>" />
                        <input type="text" placeholder="Designation" name="search[designation]" value="<?php echo $designation; ?>" />
                        <input type="submit" name="go" class="btnSearch" value="Search">
                        <input type="reset" class="btnReset" value="Reset" onclick="window.location='index.php'">
                    </p>
                </div>
                <div>
                    <a class="font-bold float-right" href="add.php">Add New</a>
                </div>
                <table class="stripped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Designation</th>
                            <th>Date of Birth</th>
                            <th>Date of Joining</th>
                            <th>Blood Group</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (!empty($result)) {
                            foreach ($result as $key => $value) {
                                if (is_numeric($key)) {
                        ?>
                                    <tr>
                                        <td><?php echo $result[$key]['name']; ?></td>
                                        <td><?php echo $result[$key]['email']; ?></td>
                                        <td><?php echo $result[$key]['mobile']; ?></td>
                                        <td><?php echo $result[$key]['designation']; ?></td>
                                        <td><?php echo $result[$key]['dob']; ?></td>
                                        <td><?php echo $result[$key]['doj']; ?></td>
                                        <td><?php echo $result[$key]['blood_group']; ?></td>
                                        <td>
                                            <a class="mr-20" href="edit.php?id=<?php echo $result[$key]["id"]; ?>">Edit</a>
                                            <a href="#" onclick="confirmDelete(<?php echo $result[$key]["id"]; ?>);">Delete</a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            }
                        }
                        if (isset($result["perpage"])) {
                            ?>
                            <tr>
                                <td colspan="8" align=right> <?php echo $result["perpage"]; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
    <script>
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete this record?")) {
                window.location.href = "delete.php?action=delete&id=" + id;
            }
        }
    </script>
</body>

</html>