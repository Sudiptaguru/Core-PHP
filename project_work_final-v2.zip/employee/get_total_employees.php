<?php
require_once __DIR__ . '/../lib/DataSource.php';

$dataSource = new DataSource();
$sql = "SELECT COUNT(*) as total FROM employee WHERE del_flag=0";
$result = $dataSource->select($sql);

$totalEmployees = 0;
if (!empty($result)) {
    $totalEmployees = $result[0]['total'];
}

echo json_encode(['total' => $totalEmployees]);
?>