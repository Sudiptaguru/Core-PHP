<?php
require_once __DIR__ . '/auth.php';
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="navbar.css" />
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>

    <!-- Content -->
    <div style="padding:20px;">
        <p>This is a protected page.</p>
        <p id="welcomeMessage">Loading...</p>
    </div>

    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'fetch_user.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === "success") {
                        var userData = response.data;
                        $("#userName").text(userData.name);
                        $("#welcomeMessage").text("Hello " + userData.name);
                        $("#profileLink").attr("href", "edit_profile.php?email=" + userData.email);

                        if (userData.isAdmin) {
                            // Add admin-specific options here if needed
                        }
                    } else {
                        $("#userName").text("Error loading user");
                        $("#welcomeMessage").text("Failed to load user data.");
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    $("#userName").text("Error loading user");
                    $("#welcomeMessage").text("An error occurred while loading user data.");
                }
            });
        });
    </script>
</body>

</html>