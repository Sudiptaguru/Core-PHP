<!DOCTYPE html>
<html>
<head>
    <title>PHP CRUD with Search and Pagination</title>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link href="../css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="auth.js"></script>
    <style>
        /* Styles from index.php */
        /* New styles for centralizing the table and adjusting pagination design */
        #employeeTable {
            margin: 0 auto;
            text-align: center;
            width: 90%;
            /* Adjust the width as needed */
        }

        #paginationContainer {
            margin-top: 20px;
            text-align: center;
        }

        .perpage-link {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 5px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            color: #333;
            text-decoration: none;
            cursor: pointer;
        }

        .perpage-link.current-page {
            background-color: #337ab7;
            color: #fff;
            border-color: #337ab7;
        }

        .perpage-link:hover {
            background-color: #ddd;
        }

        .btnSearch,
        .btnReset {
            padding: 8px 12px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 4px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            color: #333;
            text-decoration: none;
        }

        .btnReset {
            margin-left: 10px;
        }

        .font-bold {
            font-weight: bold;
        }

        .float-right {
            float: right;
        }
    </style>
    <style>
        .phppot-container {
            margin: 0 auto;
            width: 50%; /* Adjust as needed */
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="phppot-container">
        <h1>Employee Management System</h1>

        <div>
            <form name="frmSearch" method="post" action="" id="searchForm">
                <div>
                    <p>
                        <input type="text" placeholder="Name" name="search[name]" id="search_name" />
                        <input type="text" placeholder="Designation" name="search[designation]" />
                        <input type="submit" name="go" class="btnSearch" value="Search" id="searchBtn">
                        <input type="reset" class="btnReset" value="Reset" onclick="window.location='index.php'">
                    </p>
                </div>
                <div>
                    <a class="font-bold float-right" href="add_edit.php">Add New</a>
                </div>
                <table class="stripped">
                    <!-- Table structure from previous code -->
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Designation</th>
                            <th>Date of Birth</th>
                            <th>Date of Joining</th>
                            <th>Blood Group</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="employeeTable">
                    </tbody>
                </table>
            </form>
            <div id="paginationContainer">

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            function loadTable(formData) {
                $.ajax({
                    url: 'load_table.php',
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        var result = JSON.parse(response);
                        $('#employeeTable').html(result.table);
                        $('#paginationContainer').html(result.perpage);
                    }
                });
            }

            $('#searchForm').submit(function(e) {
                e.preventDefault();
                var formData = $(this).serialize();
                loadTable(formData);
            });

            $(document).on('click', '.perpage-link', function(e) {
                e.preventDefault();
                var page = $(this).val();
                var formData = $('#searchForm').serialize() + '&page=' + page;
                loadTable(formData);
            });

            $(document).on('click', '.deleteBtn', function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                if (confirm("Are you sure you want to delete this user?")) {
                    $.ajax({
                        url: 'delete.php',
                        type: 'GET',
                        data: {
                            id: id
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.status === 'success') {
                                alert(response.message);
                                loadTable($('#searchForm').serialize());
                            } else {
                                alert("Failed to delete user.");
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                            alert("An error occurred while processing your request.");
                        }
                    });
                }
            });

            // Load table on page load
            loadTable('');
        });
    </script>
</body>
</html>
