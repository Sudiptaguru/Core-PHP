<?php
require_once __DIR__ . '/../lib/DataSource.php';

$database = new DataSource();
$response = array("status" => "error", "message" => "Unknown error occurred.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $targetDirRole = "uploads/role/";
    $targetDirProfile = "uploads/profile/";

    $role = $_POST["existing_role"];
    $profile_picture = $_POST["existing_profile_picture"];

    if (!empty($_FILES["role"]["name"])) {
        $targetFileRole = $targetDirRole . basename($_FILES["role"]["name"]);
        if (move_uploaded_file($_FILES["role"]["tmp_name"], $targetFileRole)) {
            $role = $targetFileRole;
        }
    }

    if (!empty($_FILES["profile_picture"]["name"])) {
        $targetFileProfile = $targetDirProfile . basename($_FILES["profile_picture"]["name"]);
        if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFileProfile)) {
            $profile_picture = $targetFileProfile;
        }
    }

    $email = $_POST["email"];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response["message"] = "Invalid email format";
    } else {
        $checkEmailQuery = "SELECT COUNT(*) as count FROM users WHERE email = ? AND id != ?";
        $paramType = "si";
        $paramValue = array($email, $_POST["id"]);
        $result = $database->select($checkEmailQuery, $paramType, $paramValue);

        if ($result && $result[0]["count"] > 0) {
            $response["message"] = "Email already exists.";
        } else {
            $sql = "UPDATE users SET name=?, gender=?, dob=?, address=?, mobile=?, signature=?, role=?, profile_picture=?, email=? WHERE id=?";
            $paramType = 'sssssssssi';
            $paramValue = array(
                $_POST["name"],
                $_POST["gender"],
                $_POST["dob"],
                $_POST["address"],
                $_POST["mobile"],
                $_POST["signature"],
                $role,
                $profile_picture,
                $email,
                $_POST["id"]
            );

            $result = $database->execute($sql, $paramType, $paramValue);

            if ($result) {
                $response["status"] = "success";
                $response["message"] = "Record updated successfully.";
            } else {
                $response["message"] = "Failed to update record.";
            }
        }
    }
}

echo json_encode($response);
?>
