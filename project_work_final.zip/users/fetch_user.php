<?php
require_once __DIR__ . '/../lib/DataSource.php';
// Load user data from JSON files
// Database connection
$database = new DataSource();

// Fetch users from the database where is_approve = 1
$queryCondition = "WHERE is_approve = 1";
$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM users " . $queryCondition;
$query = $sql . $orderby;
$result = $database->select($query);

// Convert the database result to JSON and then decode it to an array
$jsonData = json_encode($result);
// echo $jsonData; die;
$usersData = json_decode($jsonData, true);
$adminData = json_decode(file_get_contents("../admin.json"), true);

// Retrieve logged-in user's email from session
$email = $_SESSION['email'];

// Find the user's data from JSON using the email
$userData = null;
foreach (array_merge($usersData, $adminData) as $user) {
    if ($user['email'] === $email) {
        $userData = $user;
        break;
    }
}

// Check if the user is an admin
$isAdmin = isset($userData) && in_array($userData, $adminData);
?>