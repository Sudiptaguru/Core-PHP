<?php
session_start();

// Check if user is not logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login page
    header("Location: index.html");
    exit;
}

// Database connection
$database = new DataSource();

// Fetch users from the database where is_approve = 1
$queryCondition = "WHERE is_approve = 1";
$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM users " . $queryCondition;
$query = $sql . $orderby;
$result = $database->select($query);

// Convert the database result to JSON and then decode it to an array
$jsonData = json_encode($result);
// echo $jsonData; die;
$usersData = json_decode($jsonData, true);

// Retrieve email from URL parameter
$email = $_GET['email'];

// Find the user's data from JSON using the email
$userData = null;
foreach ($usersData as $user) {
    if ($user['email'] === $email) {
        $userData = $user;
        break;
    }
}

// If user data is not found or if it's not the logged-in user, redirect to dashboard
if (!$userData || $email !== $_SESSION['email']) {
    header("Location: dashboard.php");
    exit;
}
?>