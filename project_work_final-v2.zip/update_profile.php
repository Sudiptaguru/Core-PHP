<?php
require_once __DIR__ . '/lib/DataSource.php';
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['email'])) {
    echo json_encode(["status" => "error", "message" => "You must be logged in to update your profile."]);
    exit;
}
$database = new DataSource();
$email = $_SESSION['email'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $profilePicture = $_FILES['profile_picture'];
    $existingProfilePicture = $_POST['existing_profile_picture'];
    if ($profilePicture && $profilePicture['error'] === 0) {
        $targetDir = "users/uploads/";
        $targetFile = $targetDir . basename($profilePicture["name"]);
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        if (in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            if (move_uploaded_file($profilePicture["tmp_name"], $targetFile)) {
                $profilePicturePath = $targetFile;
            } else {
                $profilePicturePath = $existingProfilePicture;
            }
        } else {
            $profilePicturePath = $existingProfilePicture;
        }
    } else {
        $profilePicturePath = $existingProfilePicture;
    }
    $query = "UPDATE users SET profile_picture = ? WHERE email = ?";
    $params = array($profilePicturePath, $email);
    $paramType = 'ss';

    $result = $database->update($query, $paramType, $params);

    if ($result) {
        echo json_encode(["status" => "success", "message" => "Profile updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update profile or no changes made."]);
    }
}
?>
