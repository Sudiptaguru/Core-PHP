<?php

//print_r($_SESSION);
//session_destroy();
?>

<div class="container">
    <!-- <h2>Welcome!</h2> -->

    <form action="<?php echo base_url('User_controller/userProfile'); ?>" method="POST">
        First Name:<?php echo $profile[0]->first_name; ?><br>
        Phone:<?php echo $profile[0]->phone; ?><br>
        
        <a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a><br>

       <!--  <p><b>File: </b> <img src="<?php echo $user['file']; ?>"></p> -->
    </form>
</div>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<!-- <h1>Name of the worker is <?php echo $n; ?></h1> -->
<!-- <h1>Welcome</h1>
<h3>
		<?php $name=$this->session->userdata('name'); ?>
		<?php $email=$this->session->userdata('email'); ?>
		Name:<?php echo $name; ?><br>
			Email:<?php echo $email; ?><br>
			<a href="<?php echo base_url('index.php/user_controller/logout'); ?>" class="logout">Logout</a>
</h3> -->
</body>
</html>

   