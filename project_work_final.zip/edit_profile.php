<?php
require_once __DIR__ . '/lib/DataSource.php';
require_once __DIR__ . '/editprofile_query.php';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Profile</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <h2>Edit Profile</h2>
    <form id="editProfileForm">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($userData['name']); ?>"><br><br>
        <label for="email">Username:</label>
        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" disabled><br><br>
        <label for="mobile">Phone:</label>
        <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($userData['mobile']); ?>"><br><br>
        <input type="submit" value="Update Profile">
    </form>
    <div id="responseMessage"></div>

    <script>
        $(document).ready(function() {
            $("#editProfileForm").on("submit", function(e) {
                e.preventDefault();

                $.ajax({
                    url: 'update_profile.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        console.log(response);
                        if (response.status === "success") {
                            alert(response.message);
                            window.location.href = "dashboard.php";
                            // $("#responseMessage").html("<p style='color: green;'>" + response.message + "</p>");
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText); // Debugging: Log the error response
                        $("#responseMessage").html("An error occurred: " + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>

</html>
