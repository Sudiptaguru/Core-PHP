-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 01, 2024 at 10:17 AM
-- Server version: 8.3.0
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'John Doe', 'john@example.com', '$2y$10$lZDrIHl1p97Rak8BXhVpS.ct2.fje6nL89ANSCcZYE1IQviBfLnN6', '2024-07-31 14:07:07'),
(2, 'Jane Smith', 'jane@example.com', NULL, '2024-07-31 14:07:07'),
(3, 'Alice Brown', 'alice@example.com', NULL, '2024-07-31 14:28:22'),
(4, 'Alice Browna', 'alicea@example.com', NULL, '2024-07-31 14:39:46'),
(13, 'adminaa', 'adminaa@gmail.com', NULL, '2024-07-31 15:56:28'),
(37, 'admin1', 'admin1@gmail.com', NULL, '2024-07-31 17:24:07'),
(40, 'admin2', 'admin2@gmail.com', NULL, '2024-07-31 17:31:46'),
(41, 'admin3', 'admin3@gmail.com', NULL, '2024-07-31 17:32:01'),
(42, 'admin4', 'admin4@gmail.com', NULL, '2024-07-31 17:32:13'),
(43, 'admin5', 'admin5@gmail.com', NULL, '2024-07-31 17:32:23'),
(48, 'admin10', 'admin10@gmail.com', NULL, '2024-08-01 03:51:56'),
(78, 'admin', 'admin@gmail.com', '$2y$10$86ObXSj/z6Xsw6K/J8D5Jux6V.tWJXugGYm0rqE3h3qSiU6UGoYH2', '2024-08-01 10:11:52');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
