<?php
session_start();

$response = array();

if (!isset($_SESSION['email'])) {
    $response['authenticated'] = false;
} else {
    $response['authenticated'] = true;
}

header('Content-Type: application/json');
echo json_encode($response);
exit;
?>
