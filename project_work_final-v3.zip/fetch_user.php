<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Ensure the session is started if not already active
}

require_once __DIR__ . '/lib/DataSource.php';

$database = new DataSource();
$queryCondition = "WHERE is_approve = 1 AND del_flag = 0";
$queryCondition1 = "WHERE role = 1 OR role = 2";
$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM users " . $queryCondition;
$sql1 = "SELECT * FROM users " . $queryCondition1;
$query = $sql . $orderby;
$query1 = $sql1 . $orderby;
$result = $database->select($query);
$result1 = $database->select($query1);
$jsonData = json_encode($result);
$jsonData1 = json_encode($result1);
// echo $jsonData1; die;
$usersData = json_decode($jsonData, true);
$adminData = json_decode($jsonData1, true);
$userData = null;

$email = $_SESSION['email']; // Ensure the email is set in the session

foreach (array_merge($usersData, $adminData) as $user) {
    if ($user['email'] === $email) {
        $userData = $user;
        break;
    }
}

// Check if the user is an admin
$isAdmin = isset($userData) && in_array($userData, $adminData);

header('Content-Type: application/json');
echo json_encode(['userData' => $userData, 'isAdmin' => $isAdmin]);
?>
