<?php
$host = "localhost";
$user = "root";  // Change if using another MySQL user
$pass = "";      // Set MySQL password if required
$dbname = "user_auth";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>