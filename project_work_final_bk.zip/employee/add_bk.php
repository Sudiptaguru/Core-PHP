<?php
require_once __DIR__ . '/lib/DataSource.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../fetch_user.php';
$database = new DataSource();

if (isset($_POST["submit"])) {
    $email = $_POST["email"];
    $checkEmailQuery = "SELECT COUNT(*) as count FROM employee WHERE email = ?";
    $paramType = "s";
    $paramValue = array($email);
    $result = $database->select($checkEmailQuery, $paramType, $paramValue);
    if ($result && $result[0]["count"] > 0) {
        $message = "Email already exists.";
    } else {
        $mobile = $_POST["mobile"];
        if (strlen($mobile) !== 10 || !is_numeric($mobile)) {
            $message = "Mobile number must be 10 digits and contain only numeric characters.";
        } else {
            $sql = "INSERT INTO employee(name, designation, dob, doj, address, blood_group, email, mobile) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            $paramType = 'ssssssss';
            $paramValue = array(
                $_POST["name"],
                $_POST["designation"],
                $_POST["dob"],
                $_POST["doj"],
                $_POST["address"],
                $_POST["blood_group"],
                $email,
                $mobile
            );
            $result = $database->insert($sql, $paramType, $paramValue);
            if (!$result) {
                $message = "Problem adding employee to the database. Please retry.";
            } else {
                header("Location: index.php");
                exit();
            }
        }
    }
}
?>
<html>

<head>

    <link href="css/style.css" type="text/css" rel="stylesheet" />
    <link href="css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <!-- <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script> -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $(".datepicker").datepicker();
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                maxDate: "+1Y"
            });
        });

        function previewImage(input, imgElement) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $(imgElement).attr('src', e.target.result).css('display', 'block');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function validateMobile(input) {
            var mobile = input.value;
            var mobileInfo = document.getElementById('mobile-info');
            if (mobile.length > 10 || isNaN(mobile)) {
                mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                input.value = input.value.slice(0, 10);
            } else {
                mobileInfo.textContent = "";
            }
        }

        function restrictInput(evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();" enctype="multipart/form-data">
            <?php if (!empty($message)) { ?>
                <div class="error">
                    <?php echo $message; ?>
                </div>
            <?php } ?>
            <h1>Add Record</h1>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label><input type="text" name="name" id="name" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label><input type="email" name="email" id="email" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label><input type="text" name="mobile" id="mobile" class="full-width " onkeyup="validateMobile(this);" onkeypress="return restrictInput(event);">
            </div>
            <div class="row">
                <label class="text-left">Designation: <span id="designation-info" class="validation-message"></span></label>
                <input type="text" name="designation" id="designation" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Date of Joining: <span id="doj-info" class="validation-message"></span></label>
                <input type="text" name="doj" id="doj" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label><textarea name="address" id="address" class="full-width"></textarea>
            </div>
            <div class="row">
                <label class="text-left">Blood Group: <span id="blood_group-count-info" class="validation-message"></span></label><input type="text" name="blood_group" id="blood_group" class="full-width ">
            </div>
            <div class="row">
                <input type="submit" name="submit" id="btnAddAction" class="full-width " value="Add" />
            </div>
        </form>
    </div>
</body>

</html>