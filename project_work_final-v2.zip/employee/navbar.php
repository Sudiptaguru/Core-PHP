

<!-- Navbar -->
<div class="navbar">
    <a href="../dashboard.php">Home</a>

    <!-- User Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">User Management</button>
        <div class="dropdown-content">
            <a href="../users/add_edit.php">Add User</a>
            <a href="../users/">View Users</a>
        </div>
    </div>

    <!-- Employee Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">Employee Management</button>
        <div class="dropdown-content">
            <a href="../employee/add_edit.php">Add Employee</a>
            <a href="../employee/">View Employees</a>
        </div>
    </div>

    <!-- User Info Dropdown -->
    <div class="dropdown right">
        <button id="" class="userDropdown dropbtn">Loading...</button>
        <div class="dropdown-content" id="dropdownContent">
            <!-- Content will be populated by jQuery -->
        </div>
    </div>
</div>
<script src="navbar.js"></script>

