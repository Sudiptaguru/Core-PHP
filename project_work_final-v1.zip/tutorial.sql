-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 09:57 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `designation` varchar(20) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `doj` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `del_flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `mobile`, `designation`, `dob`, `doj`, `address`, `blood_group`, `del_flag`) VALUES
(1, 'fdf', 'sudiptaguru710@gmail.com', '8513821591', 'fgg', '2024-05-01', '2024-05-01', 'gbngbjhn', 'AB', 0),
(2, 'fdf', 'sudiptaguru7@gmail.com', '8513821598', 'C', '2024-05-01', '2024-05-01', 'FFG', 'AB', 1),
(3, 'fdf', 'sudiptaguru9@gmail.com', '8513821598', 'C', '2024-05-01', '2024-05-01', 'jb njnm', 'AB', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `is_approve` int(11) NOT NULL DEFAULT 0,
  `del_flag` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `gender`, `dob`, `address`, `signature`, `role`, `profile_picture`, `is_approve`, `del_flag`) VALUES
(1, 'ghbh', 'abc@gmail.com', '8513821598', 'Other', '2024-05-01', 'uhui', 'fdgg', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (1) - Copy.png', 1, 0),
(2, 'rtgrf', 'def@gmail.com', NULL, NULL, NULL, NULL, 'hgbhh', NULL, NULL, 0, 0),
(3, 'fdf', 'sudiptaguru710@gmail.com', NULL, 'Male', '05/01/2024', 'fcvfbv', 'fvbvb', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (6).png', 0, 0),
(4, 'fdf', 'sudiptaguru720@gmail.com', NULL, 'Male', '05/01/2024', 'fvbfv', 'dvf', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (1).png', 0, 0),
(5, 'fdf', 'sudiptaguru721@gmail.com', NULL, 'Male', '05/01/2024', 'fvggv', 'dfdfv', 'users/uploads/toy/Screenshot (1) - Copy.png', 'users/uploads/profile/Screenshot (2) - Copy.png', 0, 0),
(6, 'fdf', 'sudiptaguru722@gmail.com', NULL, 'Male', '05/01/2024', 'fgtf', 'fvfgb', 'users/uploads/toy/Screenshot (3).png', 'users/uploads/profile/Screenshot (4).png', 0, 0),
(7, 'fdf', 'sudiptaguru723@gmail.com', '8513821598', 'Other', '05/01/2024', 'hbgh', 'cvdcg', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (1).png', 0, 0),
(8, 'abc', 'sudiptaguru725@gmail.com', '8513821598', 'Other', '05/01/2024', 'ghghg1', 'ghgh1', 'uploads/role/Screenshot (1) - Copy.png', 'uploads/profile/Screenshot (2) - Copy.png', 0, 1),
(9, 'fdf', 'sudiptaguru@gmail.com', '8513821598', 'Male', '2024-05-01', 'hbjh', 'fdgg', 'uploads/role/Screenshot (3).png', 'uploads/profile/Screenshot (5).png', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
