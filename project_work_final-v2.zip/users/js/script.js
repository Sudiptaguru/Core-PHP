$(document).ready(function () {
    $.ajax({
        url: 'auth.php',
        method: 'GET',
        dataType: 'json',
        success: function (response) {
            if (!response.authenticated) {
                window.location.href = '../index.html';
            }
        },
        error: function (xhr, status, error) {
            console.log('Authentication check failed:', error);
        }
    });

    $.ajax({
        url: 'fetch_user.php',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            if (!data || !data.userData) {
                console.error('Invalid data format received:', data);
                $('.userDropdown').text('Error loading data');
                window.location.href = '../logout.php';
                return;
            }
            var userData = data.userData;
            var isAdmin = data.isAdmin;

            // Update the user's name in the dropdown button
            $('.userDropdown').text(userData.name);

            // Hide User Management and Employee Management if not an admin
            if (!isAdmin) {
                $('.dropdown1').hide();
                window.location.href = '../logout.php';
            }

            // Populate the dropdown content
            var dropdownContent = '<a href="../edit_profile.php?email=' + userData.email + '">Profile</a>';
            dropdownContent += '<a href="../logout.php">Logout</a>';
            $('#dropdownContent').html(dropdownContent);
        },
        error: function (xhr, status, error) {
            console.error('AJAX Error: ' + status + ' ' + error);
            $('.userDropdown').text('Error loading data');
        }
    });
});