<?php
require_once __DIR__ . '/../lib/perpage.php';
require_once __DIR__ . '/../lib/DataSource.php';
$database = new DataSource();

$search = "";
$queryCondition = "WHERE del_flag = 0"; // Adding condition for del_flag
if (!empty($_POST["search"])) {
    $search = $_POST["search"];
    $queryCondition .= " AND (name LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' OR mobile LIKE '%" . $search . "%' OR designation LIKE '%" . $search . "%')";
}

$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM employee " . $queryCondition;
$href = 'index.php';

$perPage = 10;
$page = isset($_POST['page']) ? $_POST['page'] : 1;
$start = max(0, ($page - 1) * $perPage);

$query = $sql . $orderby . " LIMIT " . $start . "," . $perPage;
$result = $database->select($query);

$table = '';
if (!empty($result)) {
    foreach ($result as $row) {
        $table .= '<tr>';
        $table .= '<td>' . $row['name'] . '</td>';
        $table .= '<td>' . $row['email'] . '</td>';
        $table .= '<td>' . $row['mobile'] . '</td>';
        $table .= '<td>' . $row['designation'] . '</td>';
        $table .= '<td>' . $row['dob'] . '</td>';
        $table .= '<td>' . $row['doj'] . '</td>';
        $table .= '<td>' . $row['blood_group'] . '</td>';
        $table .= '<td>';
        $table .= '<a class="mr-20" href="add_edit.php?id=' . $row["id"] . '">Edit</a>';
        $table .= '<a href="#" class="deleteBtn" data-id="' . $row["id"] . '" onclick="confirmDelete(' . $row["id"] . ');">Delete</a>';
        $table .= '</td>';
        $table .= '</tr>';
    }
}

$perpage = '';
if (!empty($result)) {
    $perpage = showperpage($sql, $perPage, $href);
}

$response = array(
    'table' => $table,
    'perpage' => $perpage
);

echo json_encode($response);
?>
