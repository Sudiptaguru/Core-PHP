$(document).ready(function() {

    $.ajax({
        url: 'auth.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (!response.authenticated) {
                window.location.href = 'index.html';
            }
        },
        error: function(xhr, status, error) {
            console.log('Authentication check failed:', error);
        }
    });
    $.ajax({
        url: 'fetch_user.php',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === "success") {
                var userData = response.data;
                $("#userName").text(userData.name);
                $("#welcomeMessage").text("Hello " + userData.name);
                $("#profileLink").attr("href", "edit_profile.php?email=" + userData.email);

                if (userData.isAdmin) {
                    // Add admin-specific options here if needed
                }
            } else {
                $("#userName").text("Error loading user");
                $("#welcomeMessage").text("Failed to load user data.");
            }
        },
        error: function(xhr, status, error) {
            console.log(xhr.responseText);
            $("#userName").text("Error loading user");
            $("#welcomeMessage").text("An error occurred while loading user data.");
        }
    });
});