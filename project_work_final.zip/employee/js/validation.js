function validate() {
	var valid = true;
	$(".info").html('');

	if (!$("#name").val()) {
		$("#name-info").html("required.");
		valid = false;
	}
	if (!$("#email").val()) {
		$("#email-info").html("required.");
		valid = false;
	}
	if (!$("#mobile").val()) {
		$("#mobile-info").html("required.");
		valid = false;
	}
	if (!$("#designation").val()) {
		$("#designation-info").html("required.");
		valid = false;
	}
	if (!$("#dob").val()) {
		$("#dob-info").html("required.");
		valid = false;
	}
	if (!$("#doj").val()) {
		$("#doj-info").html("required.");
		valid = false;
	}
	if (!$("#address").val()) {
		$("#address-info").html("required.");
		valid = false;
	}
	return valid;
}