<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../classes/Database.php';
require_once '../classes/User.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

$request_method = $_SERVER["REQUEST_METHOD"];
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$recordsPerPage = isset($_GET['records_per_page']) ? (int)$_GET['records_per_page'] : 5;
$searchName = isset($_GET['name']) ? $_GET['name'] : '';
$searchEmail = isset($_GET['email']) ? $_GET['email'] : '';
switch($request_method) {
    case 'GET':
        handleGetRequest();
        break;
    case 'POST':
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        if ($action == 'login') {
            handleLoginRequest();
        } elseif ($action == 'logout') {
            handleLogoutRequest();
        } else {
            handlePostRequest();
        }
        break;
    case 'PUT':
        handlePutRequest();
        break;
    case 'DELETE':
        handleDeleteRequest();
        break;
    default:
        header("HTTP/1.0 405 Method Not Allowed");
        break;
}

function handleGetRequest() {
    global $user;
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $records_per_page = isset($_GET['records_per_page']) ? intval($_GET['records_per_page']) : 5;
    $from_record_num = ($page - 1) * $records_per_page;
    $search_name = isset($_GET['name']) ? $_GET['name'] : "";
    $search_email = isset($_GET['email']) ? $_GET['email'] : "";

    // Execute the read method to get the users with search parameters
    $stmt = $user->read($from_record_num, $records_per_page, $search_name, $search_email);
    $num = $stmt->rowCount();

    if ($num > 0) {
        $users_arr = array();
        $users_arr["records"] = array();
        $users_arr["paging"] = array();

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $user_item = array(
                "id" => $id,
                "name" => $name,
                "email" => $email
            );
            array_push($users_arr["records"], $user_item);
        }

        // Get total row count for accurate pagination
        $total_rows = $user->count($search_name, $search_email); // Adjust count method if needed
        $users_arr["total_rows"] = $total_rows;
        $page_url = "http://localhost/my-rest-api-ajaxcrud/api/index.php?";
        $paging = getPaging($page, $total_rows, $records_per_page, $page_url);
        $users_arr["paging"] = $paging;

        http_response_code(200);
        echo json_encode($users_arr);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "No users found."));
    }
}

function handlePostRequest() {
    global $user;
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->name) && !empty($data->email) && !empty($data->password)) {
        $user->name = $data->name;
        $user->email = $data->email;
        $user->password = password_hash($data->password, PASSWORD_DEFAULT);
        $result = $user->create();
        if($result === true) {
            http_response_code(201);
            echo json_encode(array("message" => "User was created."));
        } elseif ($result === "Email already exists") {
            http_response_code(400);
            echo json_encode(array("message" => "Email already exists."));
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Unable to create user."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Incomplete data."));
    }
}

function handlePutRequest() {
    global $user;
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->id) && (!empty($data->name) || !empty($data->email) || !empty($data->password))) {
        $user->id = $data->id;
        $user->name = $data->name;
        $user->email = $data->email;
        $user->password = password_hash($data->password, PASSWORD_DEFAULT);
        $result = $user->update();
        if($result === true) {
            http_response_code(200);
            echo json_encode(array("message" => "User was updated."));
        } elseif ($result === "Email already exists") {
            http_response_code(400);
            echo json_encode(array("message" => "Email already exists."));
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Unable to update user."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Incomplete data."));
    }
}

function handleDeleteRequest() {
    global $user;
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->id)) {
        $user->id = $data->id;
        if($user->delete()) {
            http_response_code(200);
            echo json_encode(array("message" => "User was deleted."));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Unable to delete user."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Incomplete data."));
    }
}
function handleLoginRequest() {
    global $user;
    $data = json_decode(file_get_contents("php://input"));
    if (!empty($data->email) && !empty($data->password)) {
        $user->email = $data->email;
        $user->password = $data->password;
        $result = $user->login();
        if ($result) {
            session_start();
            $_SESSION['user_id'] = $result['id'];
            $_SESSION['user_name'] = $result['name'];
            http_response_code(200);
            echo json_encode(array("message" => "Login successful.", "user" => $result));
        } else {
            http_response_code(401);
            echo json_encode(array("message" => "Login failed. Invalid email or password."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Incomplete data."));
    }
}
function handleLogoutRequest() {
    session_start();
    session_unset();
    session_destroy();
    http_response_code(200);
    echo json_encode(array("message" => "Logged out successfully."));
}

function getPaging($page, $total_rows, $records_per_page, $page_url) {
    $paging_arr = array();
    $total_pages = ceil($total_rows / $records_per_page);

    $paging_arr["first"] = $page > 1 ? "{$page_url}page=1&records_per_page={$records_per_page}" : "";
    $paging_arr["last"] = $page < $total_pages ? "{$page_url}page={$total_pages}&records_per_page={$records_per_page}" : "";
    $paging_arr["previous"] = $page > 1 ? "{$page_url}page=" . ($page - 1) . "&records_per_page={$records_per_page}" : "";
    $paging_arr["next"] = $page < $total_pages ? "{$page_url}page=" . ($page + 1) . "&records_per_page={$records_per_page}" : "";

    return $paging_arr;
}
?>
