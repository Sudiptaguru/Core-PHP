<?php
require_once __DIR__ . '/lib/DataSource.php';
session_start();

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    echo json_encode(["status" => "error", "message" => "You must be logged in to update your profile."]);
    exit;
}

// Database connection
$database = new DataSource();
$email = $_SESSION['email'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and validate form data
    $name = trim($_POST['name']);
    $mobile = trim($_POST['mobile']);

    if (empty($name) || empty($mobile)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        echo json_encode(["status" => "error", "message" => "Invalid mobile number format. It should be 10 digits."]);
        exit;
    }

    // Update user data in the database
    $query = "UPDATE users SET name = ?, mobile = ? WHERE email = ?";
    $params = array($name, $mobile, $email);
    $paramType = 'sss';
    $result = $database->update($query, $paramType, $params);

    if ($result > 0) {
        echo json_encode(["status" => "success", "message" => "Profile updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update profile or no changes made."]);
    }
}
?>
