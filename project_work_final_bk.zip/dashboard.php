<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/fetch_user.php';
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="navbar.css" />
    <title>Dashboard</title>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>

    <!-- Content -->
    <div style="padding:20px;">
        <p>This is a protected page.</p>
        <p>Hello <?php echo $userData['name']; ?></p>
    </div>

</body>

</html>