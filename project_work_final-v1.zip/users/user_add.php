<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/fetch_userparam.php';

?>
<!DOCTYPE html>
<html>

<head>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link href="../css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd"
            });

            function previewImage(input, imgElement) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $(imgElement).attr('src', e.target.result).css('display', 'block');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            $('#role').change(function() {
                previewImage(this, '#role-preview');
            });

            $('#profile_picture').change(function() {
                previewImage(this, '#profile-picture-preview');
            });

            $('#mobile').on('keyup', function() {
                validateMobile(this);
            }).on('keypress', function(evt) {
                return restrictInput(evt);
            });

            function validateMobile(input) {
                var mobile = input.value;
                var mobileInfo = document.getElementById('mobile-info');
                if (mobile.length > 10 || isNaN(mobile)) {
                    mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                    input.value = input.value.slice(0, 10);
                } else {
                    mobileInfo.textContent = "";
                }
            }

            function restrictInput(evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            }

            $('#frmToy').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                var url = '<?php echo $isEdit ? "update_user.php" : "process_form.php"; ?>';

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var jsonResponse = JSON.parse(response);
                        if (jsonResponse.status === 'success') {
                            alert(jsonResponse.message);
                            window.location.href = "index.php";
                        } else {
                            alert(jsonResponse.message);
                        }
                    }
                });
            });
        });
    </script>

    <style>
        .phppot-container {
            margin: 0 auto;
            width: 50%; /* Adjust as needed */
        }
    </style>
</head>

<body>
    <?php require_once __DIR__ . '/navbar.php'; ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" enctype="multipart/form-data" onClick="return validate();">
            <h1><?php echo $isEdit ? "Edit" : "Add"; ?> Record</h1>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label>
                <input type="text" name="name" id="name" class="full-width" value="<?php echo htmlspecialchars($record["name"] ?? ''); ?>">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label>
                <input type="email" name="email" id="email" class="full-width" value="<?php echo htmlspecialchars($record["email"] ?? ''); ?>">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label>
                <input type="text" name="mobile" id="mobile" class="full-width" value="<?php echo htmlspecialchars($record["mobile"] ?? ''); ?>" onkeyup="validateMobile(this);" onkeypress="return restrictInput(event);">
            </div>
            <div class="row">
                <label class="text-left">Gender: <span id="gender-info" class="validation-message"></span></label>
                <select name="gender" id="gender" class="full-width">
                    <option value="Male" <?php if ($record["gender"] ?? '' == "Male") echo "selected"; ?>>Male</option>
                    <option value="Female" <?php if ($record["gender"] ?? '' == "Female") echo "selected"; ?>>Female</option>
                    <option value="Other" <?php if ($record["gender"] ?? '' == "Other") echo "selected"; ?>>Other</option>
                </select>
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker" value="<?php echo htmlspecialchars($record["dob"] ?? ''); ?>">
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label>
                <textarea name="address" id="address" class="full-width"><?php echo htmlspecialchars($record["address"] ?? ''); ?></textarea>
            </div>
            <div class="row">
                <label class="text-left">Signature: <span id="signature-info" class="validation-message"></span></label>
                <input type="text" name="signature" id="signature" class="full-width" value="<?php echo htmlspecialchars($record["signature"] ?? ''); ?>">
            </div>
            <div class="row">
                <label class="text-left">Role: <span id="role-info" class="validation-message"></span></label>
                <input type="file" name="role" id="role" class="full-width" accept="image/*">
                <?php if ($isEdit && !empty($record["role"])): ?>
                    <input type="hidden" name="existing_role" value="<?php echo htmlspecialchars($record["role"]); ?>">
                    <img id="role-preview" src="<?php echo htmlspecialchars($record["role"]); ?>" alt="Role Image" style="width: 100px; height: 100px;">
                <?php else: ?>
                    <img id="role-preview" src="#" alt="Role Image" style="width: 100px; height: 100px; display: none;">
                <?php endif; ?>
            </div>
            <div class="row">
                <label class="text-left">Profile Picture: <span id="profile_picture-info" class="validation-message"></span></label>
                <input type="file" name="profile_picture" id="profile_picture" class="full-width" accept="image/*">
                <?php if ($isEdit && !empty($record["profile_picture"])): ?>
                    <input type="hidden" name="existing_profile_picture" value="<?php echo htmlspecialchars($record["profile_picture"]); ?>">
                    <img id="profile-picture-preview" src="<?php echo htmlspecialchars($record["profile_picture"]); ?>" alt="Profile Picture" style="width: 100px; height: 100px;">
                <?php else: ?>
                    <img id="profile-picture-preview" src="#" alt="Profile Picture" style="width: 100px; height: 100px; display: none;">
                <?php endif; ?>
            </div>
            <div class="row">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($record["id"]); ?>">
                <?php endif; ?>
                <input type="submit" name="submit" id="btn-submit" value="Submit" class="full-width">
            </div>
        </form>
    </div>
</body>

</html>
