<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_form'])) {
    // Check if the form is submitted
    if (isset($_POST['selected_option'])) {
        // Encode the selected option and store it in a session variable
        $selectedOption = $_POST['selected_option'];
        $dataQty = $_POST['data_qty'];
        $dataImg = $_POST['data_img'];
        $_SESSION['encoded_value'] = base64_encode($selectedOption);
        $_SESSION['data_qty'] = base64_encode($dataQty);
        $_SESSION['data_img'] = base64_encode($dataImg);

        // Redirect to the next page
        header("Location: next_page2.php");
        exit();
    } else {
        // Debugging: Output an error message
        echo "Error: Selected option not found.";
    }
}
if (isset($_SESSION['encoded_value'])) {
    // Decode the value
    $decodedValue = base64_decode($_SESSION['encoded_value']);
    $dataQty = base64_decode($_SESSION['data_qty']);
    $dataImg = base64_decode($_SESSION['data_img']);

    // Display details or perform other actions with $decodedValue
    echo "<h2>Details for: $decodedValue</h2>";
    echo "<p>Data Qty: $dataQty</p>";
    echo "<p>Data Img: $dataImg</p>";

    // Clear the session variable
    // unset($_SESSION['encoded_value']);
    // unset($_SESSION['data_qty']);
    // unset($_SESSION['data_img']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Next Page</title>
</head>
<body>
    <h2>Next Page</h2>
    <form action="" method="post">
        <?php
        // Display hidden inputs with data from previous page
        if (isset($_SESSION['encoded_value'])) {
            $selectedOption = base64_decode($_SESSION['encoded_value']);
            $dataQty = base64_decode($_SESSION['data_qty']);
            $dataImg = base64_decode($_SESSION['data_img']);
            echo "<input type='hidden' name='selected_option' value='$selectedOption'>";
            echo "<input type='hidden' name='data_qty' value='$dataQty'>";
            echo "<input type='hidden' name='data_img' value='$dataImg'>";
        } else {
            echo "Error: Data not found.";
        }
        ?>
        <!-- Add a submit button -->
        <input type="submit" name="submit_form" value="Submit">
    </form>
</body>
</html>
