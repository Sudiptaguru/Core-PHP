<!-- Navbar -->
<div class="navbar">
    <a href="#home">Home</a>

    <!-- User Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">User Management</button>
        <div class="dropdown-content">
            <a href="../users/user_add.php">Add User</a>
            <a href="../users/">View Users</a>
        </div>
    </div>

    <!-- Employee Management Dropdown -->
    <div class="dropdown">
        <button class="dropbtn">Employee Management</button>
        <div class="dropdown-content">
            <a href="../employee/add.php">Add Employee</a>
            <a href="../employee/">View Employees</a>
        </div>
    </div>

    <!-- User Info Dropdown -->
    <div class="dropdown right">
        <button class="dropbtn"><?php echo $userData['name']; ?></button>
        <div class="dropdown-content">
            <?php if ($isAdmin) : ?>
                <!-- Admin specific options could go here -->
            <?php else : ?>
                <a href="../edit_profile.php?email=<?php echo $email; ?>">Profile</a>
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</div>