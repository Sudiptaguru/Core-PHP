<?php
require_once __DIR__ . '/../lib/DataSource.php';

$database = new DataSource();

$response = array();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM employee WHERE id=?";
    $paramType = 'i';
    $paramValue = array($id);
    $result = $database->select($sql, $paramType, $paramValue);

    if (!empty($result)) {
        $response['status'] = 'success';
        $response['data'] = $result[0]; // Assuming there's only one record for the given ID
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No record found';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid ID';
}

echo json_encode($response);
?>
