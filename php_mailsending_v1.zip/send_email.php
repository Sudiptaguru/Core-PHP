<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Set response header
header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    // SMTP Configuration
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';  // Your SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'sudiptaguru74@gmail.com';              // Replace with your email
    $mail->Password   = 'foffnjiyjmjkpocp';                 // Replace with your app password
    $mail->SMTPSecure = 'tls';                               // Enable TLS encryption
    $mail->Port       = 587;                                 // TCP port to connect to

    // Email template
    $template = file_get_contents('email_template.html');

    // Retrieve form data
    $senderName = $_POST['sender_name'];
    $recipientEmail = $_POST['to'];
    $recipientName = $_POST['name'];
    $comment = $_POST['comment'];

    // Replace placeholders
    $mailContent = str_replace(
        ['{sender_name}', '{name}', '{comment}'],
        [$senderName, $recipientName, $comment],
        $template
    );

    // Set up the email content
    $mail->setFrom('sudiptaguru74@gmail.com', $senderName);
    $mail->addAddress($recipientEmail, $recipientName);
    $mail->isHTML(true);
    $mail->Subject = 'Subject of the Email';
    $mail->Body = $mailContent;

    // Send the email
    $mail->send();

    // Prepare success response
    $response['success'] = true;
    $response['message'] = 'Email has been sent successfully.';
} catch (Exception $e) {
    // Prepare failure response
    $response['success'] = false;
    $response['message'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

// Send JSON response
echo json_encode($response);