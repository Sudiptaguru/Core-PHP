<!DOCTYPE html>
<html>

<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" type="text/css" href="css/navbar.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>
    <h2>Edit Profile</h2>
    <form id="editProfileForm">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name"><br><br>
        <label for="email">Username:</label>
        <input type="text" id="email" name="email" disabled><br><br>
        <label for="mobile">Phone:</label>
        <input type="text" id="mobile" name="mobile"><br><br>
        <input type="submit" value="Update Profile">
    </form>
    <div id="responseMessage"></div>

    <script>
        $.ajax({
            url: 'base_url.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                var baseUrl = response.base_url;
                $('head').append('<link rel="stylesheet" href="' + baseUrl + '/css/navbar.css">');
                $('head').append('<script src="' + baseUrl + '/js/navbar.js"><\/script>');
            },
            error: function(xhr, status, error) {
                console.error('Error fetching base URL:', error);
            }
        });;

        $.ajax({
            url: 'auth.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (!response.authenticated) {
                    window.location.href = 'index.html';
                }
            },
            error: function(xhr, status, error) {
                console.log('Authentication check failed:', error);
            }
        });
        $(document).ready(function() {
            // Fetch user data when the page loads
            $.ajax({
                url: 'editprofile_query.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === "success") {
                        $("#name").val(response.data.name);
                        $("#email").val(response.data.email);
                        $("#mobile").val(response.data.mobile);
                    } else {
                        $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    $("#responseMessage").html("An error occurred while fetching data: " + xhr.responseText);
                }
            });

            // Handle form submission
            $("#editProfileForm").on("submit", function(e) {
                e.preventDefault();

                $.ajax({
                    url: 'update_profile.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            alert(response.message);
                            window.location.href = "dashboard.php";
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $("#responseMessage").html("An error occurred: " + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>

</html>