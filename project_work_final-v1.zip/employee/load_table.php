<?php
require_once __DIR__ . '/../lib/perpage.php';
require_once __DIR__ . '/../lib/DataSource.php';
$database = new DataSource();

$name = "";
$designation = "";

$queryCondition = "WHERE del_flag = 0"; // Adding condition for del_flag
if (!empty($_POST["search"])) {
    foreach ($_POST["search"] as $k => $v) {
        if (!empty($v)) {
            $queryCases = array(
                "name",
                "designation"
            );
            if (in_array($k, $queryCases)) {
                if (!empty($queryCondition)) {
                    $queryCondition .= " AND ";
                } else {
                    $queryCondition .= " WHERE ";
                }
            }
            switch ($k) {
                case "name":
                    $name = $v;
                    $queryCondition .= "name LIKE '" . $v . "%'";
                    break;
                case "designation":
                    $designation = $v;
                    $queryCondition .= "designation LIKE '" . $v . "%'";
                    break;
            }
        }
    }
}
$orderby = " ORDER BY id desc";
$sql = "SELECT * FROM employee " . $queryCondition;
$href = 'index.php';

$perPage = 10;
$page = 1;
if (isset($_POST['page'])) {
    $page = $_POST['page'];
}
$start = ($page - 1) * $perPage;
if ($start < 0)
    $start = 0;

$query = $sql . $orderby . " limit " . $start . "," . $perPage;
$result = $database->select($query);

$table = '';
if (!empty($result)) {
    foreach ($result as $key => $value) {
        if (is_numeric($key)) {
            $table .= '<tr>';
            $table .= '<td>' . $result[$key]['name'] . '</td>';
            $table .= '<td>' . $result[$key]['email'] . '</td>';
            $table .= '<td>' . $result[$key]['mobile'] . '</td>';
            $table .= '<td>' . $result[$key]['designation'] . '</td>';
            $table .= '<td>' . $result[$key]['dob'] . '</td>';
            $table .= '<td>' . $result[$key]['doj'] . '</td>';
            $table .= '<td>' . $result[$key]['blood_group'] . '</td>';
            $table .= '<td>';
            $table .= '<a class="mr-20" href="employee_add.php?id=' . $result[$key]["id"] . '">Edit</a>';
            $table .= '<a href="#" class="deleteBtn" data-id="' . $result[$key]["id"] . '" onclick="confirmDelete(' . $result[$key]["id"] . ');">Delete</a>';
            $table .= '</td>';
            $table .= '</tr>';
        }
    }
}

$perpage = '';
if (!empty($result)) {
    $perpage = showperpage($sql, $perPage, $href);
}

$response = array(
    'table' => $table,
    'perpage' => $perpage
);

echo json_encode($response);
?>
