
<!DOCTYPE html>
<html>

<head>
    <link href="../css/style.css" type="text/css" rel="stylesheet" />
    <link href="../css/form.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'check_auth.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (!response.authenticated) {
                        window.location.href = '../index.html';
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Authentication check failed:', error);
                }
            });
            $(".datepicker").datepicker();
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                maxDate: "+1Y"
            });

            function previewImage(input, imgElement) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $(imgElement).attr('src', e.target.result).css('display', 'block');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            $('#role').change(function() {
                previewImage(this, '#role-preview');
            });

            $('#profile_picture').change(function() {
                previewImage(this, '#profile-picture-preview');
            });

            $('#mobile').on('keyup', function() {
                validateMobile(this);
            }).on('keypress', function(evt) {
                return restrictInput(evt);
            });

            function validateMobile(input) {
                var mobile = input.value;
                var mobileInfo = document.getElementById('mobile-info');
                if (mobile.length > 10 || isNaN(mobile)) {
                    mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                    input.value = input.value.slice(0, 10);
                } else {
                    mobileInfo.textContent = "";
                }
            }

            function restrictInput(evt) {
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                    return false;
                }
                return true;
            }

            $('#frmToy').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    url: 'process_form.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var jsonResponse = JSON.parse(response);
                        if (jsonResponse.status === 'success') {
                            alert(jsonResponse.message);
                            window.location.href = "index.php";
                        } else {
                            alert(jsonResponse.message);
                        }
                    }
                });
            });
        });
    </script>

    <style>
        .phppot-container {
            margin: 0 auto;
            width: 50%;
            /* Adjust as needed */
        }
    </style>
</head>

<body>
    <?php require_once __DIR__ . '/navbar.php'; ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" enctype="multipart/form-data" onClick="return validate();">
            <h1>Add Record</h1>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label><input type="text" name="name" id="name" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label><input type="email" name="email" id="email" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label><input type="text" name="mobile" id="mobile" class="full-width " onkeyup="validateMobile(this);" onkeypress="return restrictInput(event);">
            </div>
            <div class="row">
                <label class="text-left">Designation: <span id="designation-info" class="validation-message"></span></label>
                <input type="text" name="designation" id="designation" class="full-width ">
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Date of Joining: <span id="doj-info" class="validation-message"></span></label>
                <input type="text" name="doj" id="doj" class="full-width datepicker">
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label><textarea name="address" id="address" class="full-width"></textarea>
            </div>
            <div class="row">
                <label class="text-left">Blood Group: <span id="blood_group-count-info" class="validation-message"></span></label><input type="text" name="blood_group" id="blood_group" class="full-width ">
            </div>
            <div class="row">
                <input type="submit" name="submit" id="btnAddAction" class="full-width " value="Add" />
            </div>
        </form>
    </div>
</body>

</html>