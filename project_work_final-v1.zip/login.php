<?php
require_once __DIR__ . '/lib/DataSource.php';
session_start();

// Database connection
$database = new DataSource();

// Fetch users from the database where is_approve = 1
$queryCondition = "WHERE is_approve = 1";
$orderby = " ORDER BY id DESC";
$sql = "SELECT * FROM users " . $queryCondition;
$query = $sql . $orderby;
$result = $database->select($query);

// Convert the database result to JSON and then decode it to an array
$jsonData = json_encode($result);
// echo $jsonData; die;
$usersData = json_decode($jsonData, true);
// print_r($usersData); die;

// Load admin data from JSON fil
// $usersData = json_decode(file_get_contents("users.json"), true);
$adminData = json_decode(file_get_contents("admin.json"), true);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve email and mobile from form
    $email = $_POST['email'];
    $mobile = $_POST['mobile']; // Assuming 'mobile' is the form field name for mobile number

    // Check if the provided credentials match any user in the users data
    foreach ($usersData as $userData) {
        if ($email === $userData['email'] && $mobile == $userData['mobile']) {
            // Check if the user is approved
            if ($userData['is_approve'] == 1) {
                // Set session variables
                $_SESSION['email'] = $email;
                // Return success response
                echo "success";
                exit;
            } else {
                echo "Your account is not approved yet.";
                exit;
            }
        }
    }

    // Check if the provided credentials match any admin in the admin data
    foreach ($adminData as $admin) {
        if ($email === $admin['email'] && $mobile == $admin['mobile']) { // Assuming 'mobile' is the key in admin data
            // Set session variables
            $_SESSION['email'] = $email;
            // Return success response
            echo "success";
            exit;
        }
    }

    // Return failure response
    echo "Invalid username or phone";
    exit;
}
?>
