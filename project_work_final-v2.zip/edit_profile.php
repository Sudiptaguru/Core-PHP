<!DOCTYPE html>
<html>

<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" type="text/css" href="css/navbar.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>
    <h2>Edit Profile</h2>
    <form id="editProfileForm" enctype="multipart/form-data">
        <label for="profile_picture">Profile Picture:</label>
        <input type="file" id="profile_picture" name="profile_picture" accept="image/*"><br><br>
        <img id="profileImagePreview" src="#" alt="Profile Image Preview" style="display: none; width: 150px; height: 150px;"/><br><br>
        <input type="hidden" id="existing_profile_picture" name="existing_profile_picture">
        <input type="submit" value="Update Profile">
    </form>
    <div id="responseMessage"></div>

    <script>
        // Function to preview the profile picture before upload
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#profileImagePreview').attr('src', e.target.result).show();
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Attach the readURL function to the profile picture input change event
        $("#profile_picture").change(function () {
            readURL(this);
        });

        $.ajax({
            url: 'auth.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (!response.authenticated) {
                    window.location.href = 'index.html';
                }
            },
            error: function(xhr, status, error) {
                console.log('Authentication check failed:', error);
            }
        });

        $(document).ready(function() {
            // Fetch user data when the page loads
            $.ajax({
                url: 'editprofile_query.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === "success") {
                        if (response.data.profile_picture) {
                            $('#profileImagePreview').attr('src', response.data.profile_picture).show();
                            $('#existing_profile_picture').val(response.data.profile_picture);
                        }
                    } else {
                        $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    $("#responseMessage").html("An error occurred while fetching data: " + xhr.responseText);
                }
            });

            // Handle form submission
            $("#editProfileForm").on("submit", function(e) {
                e.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    url: 'update_profile.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === "success") {
                            alert(response.message);
                            window.location.href = "dashboard.php";
                        } else {
                            $("#responseMessage").html("<p style='color: red;'>" + response.message + "</p>");
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        $("#responseMessage").html("An error occurred: " + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>

</html>
