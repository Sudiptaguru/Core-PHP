<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Ensure the session is started if not already active
}

require_once __DIR__ . '/lib/DataSource.php';

$database = new DataSource();
$email = $_SESSION['email']; // Ensure the email is set in the session

// Fetch user data
$query = "SELECT * FROM users WHERE email = ?";
$params = array($email);
$paramType = 's';
$result = $database->select($query, $paramType, $params);

$userData = $result ? $result[0] : null;

// Check if the user is an admin
$isAdmin = $userData && in_array($userData['role'], [1, 2]);

header('Content-Type: application/json');
echo json_encode(['userData' => $userData, 'isAdmin' => $isAdmin]);
?>
