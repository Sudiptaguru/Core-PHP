<?php
require_once __DIR__ . '/lib/DataSource.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../fetch_user.php';
$database = new DataSource();
if (!empty($_POST["submit"])) {
    $targetDirRole = "uploads/toy/";
    $targetDirProfile = "uploads/profile/";

    // Role File
    $targetFileRole = $targetDirRole . basename($_FILES["role"]["name"]);
    $imageFileTypeRole = strtolower(pathinfo($targetFileRole, PATHINFO_EXTENSION));

    // Profile Picture File
    $targetFileProfile = $targetDirProfile . basename($_FILES["profile_picture"]["name"]);
    $imageFileTypeProfile = strtolower(pathinfo($targetFileProfile, PATHINFO_EXTENSION));

    // Check if file already exists
    if (file_exists($targetFileRole) && !empty($_FILES["role"]["name"])) {
        unlink($targetFileRole); // Delete the existing file
    }

    if (file_exists($targetFileProfile) && !empty($_FILES["profile_picture"]["name"])) {
        unlink($targetFileProfile); // Delete the existing file
    }

    // Check file size and type
    if ($_FILES["role"]["size"] > 500000 || ($imageFileTypeRole != "jpg" && $imageFileTypeRole != "png" && $imageFileTypeRole != "jpeg" && $imageFileTypeRole != "gif")) {
        // Only JPG, JPEG, PNG & GIF files are allowed for role, and the file size should be less than 500KB.
    }

    if ($_FILES["profile_picture"]["size"] > 500000 || ($imageFileTypeProfile != "jpg" && $imageFileTypeProfile != "png" && $imageFileTypeProfile != "jpeg" && $imageFileTypeProfile != "gif")) {
        // Only JPG, JPEG, PNG & GIF files are allowed for profile picture, and the file size should be less than 500KB.
    }

    // Move uploaded files to target directories and update existing files
    if (!empty($_FILES["role"]["tmp_name"])) {
        move_uploaded_file($_FILES["role"]["tmp_name"], $targetFileRole);
        $role = $targetFileRole;
    } else {
        $role = $_POST["existing_role"];
    }

    if (!empty($_FILES["profile_picture"]["tmp_name"])) {
        move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetFileProfile);
        $profile_picture = $targetFileProfile;
    } else {
        $profile_picture = $_POST["existing_profile_picture"];
    }

    // Unique email validation
    $email = $_POST["email"];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format";
    } else {
        $checkEmailQuery = "SELECT COUNT(*) as count FROM users WHERE email = ? AND id != ?";
        $paramType = "si";
        $paramValue = array($email, $_GET["id"]);
        $result = $database->select($checkEmailQuery, $paramType, $paramValue);
        if ($result && $result[0]["count"] > 0) {
            $message = "Email already exists.";
        } else {
            // Update the record in the database
            $sql = "UPDATE users SET name=?, gender=?, dob=?, address=?, mobile=?, signature=?, role=?, profile_picture=?, email=? WHERE id=?";
            $paramType = 'sssssssssi';
            $paramValue = array(
                $_POST["name"],
                $_POST["gender"],
                $_POST["dob"],
                $_POST["address"],
                $_POST["mobile"],
                $_POST["signature"],
                $role,
                $profile_picture,
                $email,
                $_GET["id"]
            );
            $result = $database->execute($sql, $paramType, $paramValue);
            if ($result) {
                header("Location: index.php");
                exit();
            }
        }
    }
}

// Fetch the record from the database
$sql = "SELECT * FROM users WHERE id=?";
$paramType = 'i';
$paramValue = array(
    $_GET["id"]
);
$result = $database->select($sql, $paramType, $paramValue);
?>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/form.css" />
    <link rel="stylesheet" type="text/css" href="../navbar.css" />
    <!-- <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script> -->
    <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"> -->
    <!-- jQuery -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="./js/validation.js" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $(".datepicker").datepicker();
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: "yy-mm-dd",
                minDate: new Date(),
                maxDate: "+1Y"
            });
        });

        function previewImage(input, imgElement) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $(imgElement).attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        function validateMobile(input) {
            var mobile = input.value;
            var mobileInfo = document.getElementById('mobile-info');
            if (mobile.length > 10 || isNaN(mobile)) {
                mobileInfo.textContent = "Mobile number must be 10 digits and contain only numeric characters.";
                input.value = input.value.slice(0, 10);
            } else {
                mobileInfo.textContent = "";
            }
        }

        function restrictInput(evt) {
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>
    <div class="phppot-container tile-container text-center">
        <form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();" enctype="multipart/form-data">
            <h1>Edit Record</h1>
            <?php if (!empty($message)) { ?>
                <div class="error">
                    <?php echo $message; ?>
                </div>
            <?php } ?>
            <div class="row">
                <label class="text-left">Name: <span id="name-info" class="validation-message"></span></label>
                <input type="text" name="name" id="name" class="full-width" value="<?php echo $result[0]["name"]; ?>">
            </div>
            <div class="row">
                <label class="text-left">Email: <span id="email-info" class="validation-message"></span></label>
                <input type="email" name="email" id="email" class="full-width" value="<?php echo $result[0]["email"]; ?>">
            </div>
            <div class="row">
                <label class="text-left">Mobile: <span id="mobile-info" class="validation-message"></span></label><input type="text" name="mobile" id="mobile" class="full-width" value="<?php echo $result[0]["mobile"]; ?>" onkeyup="validateMobile(this);" onkeypress="return restrictInput(event);">
            </div>
            <div class="row">
                <label class="text-left">Gender: <span id="gender-info" class="validation-message"></span></label>
                <select name="gender" id="gender" class="full-width">
                    <option value="Male" <?php if ($result[0]["gender"] == "Male") echo "selected"; ?>>Male</option>
                    <option value="Female" <?php if ($result[0]["gender"] == "Female") echo "selected"; ?>>Female</option>
                    <option value="Other" <?php if ($result[0]["gender"] == "Other") echo "selected"; ?>>Other</option>
                </select>
            </div>
            <div class="row">
                <label class="text-left">Date of Birth: <span id="dob-info" class="validation-message"></span></label>
                <input type="text" name="dob" id="dob" class="full-width datepicker" value="<?php echo $result[0]["dob"]; ?>">
            </div>
            <div class="row">
                <label class="text-left">Address: <span id="address-info" class="validation-message"></span></label><textarea name="address" id="address" class="full-width"><?php echo $result[0]["address"]; ?></textarea>
            </div>
            <div class="row">
                <label class="text-left">Signature: <span id="signature-info" class="validation-message"></span></label>
                <input type="text" name="signature" id="signature" class="full-width" value="<?php echo $result[0]["signature"]; ?>">
            </div>
            <div class="row">
                <label class="text-left">Role: <span id="role-info" class=""></span></label>
                <input type="file" name="role" id="role" class="full-width" onchange="previewImage(this, '#role-preview');" accept="image/*">
            </div>
            <div class="row">
                <img id="role-preview" src="<?php echo $result[0]["role"]; ?>" alt="Role Image" style="width: 100px; height: 100px;">
            </div>
            <div class="row">
                <label class="text-left">Profile Picture: <span id="profile-picture-info" class=""></span></label>
                <input type="file" name="profile_picture" id="profile_picture" class="full-width" onchange="previewImage(this, '#profile-picture-preview');" accept="image/*">
            </div>
            <div class="row">
                <img id="profile-picture-preview" src="<?php echo $result[0]["profile_picture"]; ?>" alt="Profile Picture" style="width: 100px; height: 100px;">
            </div>
            <input type="hidden" name="existing_role" value="<?php echo $result[0]["role"]; ?>">
            <input type="hidden" name="existing_profile_picture" value="<?php echo $result[0]["profile_picture"]; ?>">
            <div class="row">
                <input type="submit" name="submit" id="btnAddAction" class="full-width" value="Save" />
            </div>
        </form>
    </div>
</body>

</html>