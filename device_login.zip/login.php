<?php
session_start();
require 'db.php';

function getDeviceId() {
    return hash('sha256', $_SERVER['HTTP_USER_AGENT'] . $_SERVER['REMOTE_ADDR']);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $userId = $user['id'];
        $deviceId = getDeviceId();
        $userIp = $_SERVER['REMOTE_ADDR'];
        $userAgent = $_SERVER['HTTP_USER_AGENT'];

        $query = "SELECT * FROM user_devices WHERE user_id = ? AND device_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $userId, $deviceId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $updateQuery = "UPDATE user_devices SET last_login = NOW(), ip_address = ? WHERE user_id = ? AND device_id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("sis", $userIp, $userId, $deviceId);
            $updateStmt->execute();
        } else {
            $insertQuery = "INSERT INTO user_devices (user_id, device_id, ip_address, user_agent) VALUES (?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("isss", $userId, $deviceId, $userIp, $userAgent);
            $insertStmt->execute();
            echo "New device detected! Please verify via OTP or email.";
            exit;
        }

        $_SESSION['user_id'] = $userId;
        $_SESSION['username'] = $username;

        header("Location: dashboard.php");
        exit;
    } else {
        echo "Invalid login!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="post">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>