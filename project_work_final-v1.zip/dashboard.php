<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="navbar.css" />
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <!-- Navbar -->
    <?php
    require_once __DIR__ . '/navbar.php';
    ?>

    <!-- Content -->
    <div style="padding:20px;">
        <p>This is a protected page.</p>
        <p class="" id="">Hello <span class="userDropdown">Loading...</span></p>
    </div>
</body>

</html>